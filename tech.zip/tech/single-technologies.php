<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<main>
	<?php if( get_field('banner_image',8) ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image',8); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Technology</h2>
				</div>
			</div>
		</div>	
	</section>
		

	<div class="page_outer">
		<div class="submenu_wrap submenu_minus">
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
			<div class="menu-heading">Menu</div>
		</div>
		<?php 
			$categories = get_terms(
						array('technology-category'),
						array(
						        'hide_empty'    => false,
						        'orderby'       => 'title',
						        'order'         => 'ASC'
						    )
						);
				//print_r($categories);

		?>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<ul>
					<?php foreach ($categories as $key => $value) { 
						$term_link = get_term_link($value->term_id , 'technology-category' );
					?>
					<li><a href="<?php echo $term_link ?>"><?php echo $value->name; ?></a></li>
					
					<?php } ?>
				</ul>
			</div>
		</div>
		<section class="page_content_wrapper">
			<?php
				 $terms = wp_get_post_terms( $post->ID,'technology-category'); 
				$industry_name = $terms[0]->name; ?>
			<div class="triangle_box">
				<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
				<div class="tech_box">
					<span>Why tech?</span>
				</div>
				<div class="hexagon_title_box">
					<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
						<div class="industry_color_overlay" style="background-color: rgba(0, 137, 207, 0.8);"></div>
						<div class="industry_text"><?php echo $industry_name; ?></div>
					</div>
				</div>
				
			</div>
			<div class="page_content">
				<div class="container">
					<div class="row">
						<?php 

						while ( have_posts() ) : the_post(); ?>
							
							<div class="col-xs-12 col-sm-12 col-md-12">
								<h1 class="section_head margin_bottom_20"><?php the_title(); ?></h1>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-8">
								<h2 class="section_sub_head margin_bottom_20"><?php the_field('sub_heading'); ?></h2>
							</div>
							<?php if(has_post_thumbnail()){
								$class = 'col-md-8' ;
							}else{
								$class = 'col-md-12' ;
							} ?>
							<div class="col-xs-12 col-sm-12 <?php echo $class; ?>">
								<div class="page_vc_content">
									<?php the_content(); ?> 
								</div>
							</div>
							<?php if(has_post_thumbnail()) : ?>
								<div class="col-xs-12 col-sm-12 col-md-4">
									<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" width="100%">
								</div>
							<?php endif ; ?>	
						<?php endwhile;	?>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="tp-caption rev_layer_in_column" id="slide-19-layer-5" style="z-index: 35; white-space: normal; font-size: 40px; line-height: 40px; font-weight: 700; color: rgb(0, 137, 207); display: block; font-family: Cairo; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 10px 0px 0px; padding: 0px 30px; letter-spacing: 0px; min-height: 0px; min-width: 100%; max-height: none; max-width: 100%; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; text-align: center;">DC's Leading Website Designers &amp; Developers </div>
							<div class="tp-caption rev_layer_in_column rs-toggle-content-active" style="z-index: 34; white-space: normal; font-size: 40px; line-height: 40px; font-weight: 200; color: rgba(0, 0, 0, 0.75); display: block; font-family: Cairo; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 12px 0px 0px; padding: 0px 30px; letter-spacing: 0px; min-height: 0px; min-width: 100%; max-height: none; max-width: 100%; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; text-align: center;">See some examples of our work: </div>
							<?php 
							echo do_shortcode('[waving width="100%" theme="light" all="0" showCat="true" /]');
							//putRevSlider("WebDev-Projects") ?>
						</div>
					</div>
				</div>
			</div>
		</section>	
	</div>
</main>

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
