<?php 
/*
Template Name: Contact Us Template
*/
?>
<?php get_header(); ?>
<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Contact Us</h2>
				</div>
			</div>
		</div>	
	</section>

<div class="page_outer">
	<div class="submenu_wrap submenu_minus">
		<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
		<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
		<div class="menu-heading">Menu</div>
	</div>
	<?php
	global $post;
	
    //GET CHILD PAGES IF THERE ARE ANY
    $children = get_pages('child_of='.$post->ID);
 
    //GET PARENT PAGE IF THERE IS ONE
    $parent = $post->post_parent;
    //echo $parent ; 
 
    //DO WE HAVE SIBLINGS?
    $siblings =  get_pages('child_of='.$parent);
    //print_r($siblings);
 
    if( count($children) != 0) {
       $args = array(
         'depth' => 1,
         'title_li' => '',
         'child_of' => $post->ID
       );
 
    } elseif($parent != 0) {
        $args = array(
             'depth' => 1,
             'title_li' => '',
             'exclude' => $post->ID,
             'child_of' => $parent
           );
    }
    $parent_id = get_post_ancestors( $post->ID );
    //Show pages if this page has more than one sibling 
    // and if it has children 
    if(count($siblings) > 1 && !is_null($args))   
    { ?>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<ul class="pages-list">
	         		<li><a href="<?php the_permalink($parent_id[0]); ?>"><?php echo get_the_title($parent_id[0]); ?></a></li>
	         		<?php wp_list_pages($args);  ?>
	         	</ul>
			</div>
		</div>
	<?php } ?>			
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
			<div class="tech_box">
				
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-4">
						<h1 class="section_head"><?php the_title(); ?></h1>
						<div class="page_vc_content">
							<?php 
								while ( have_posts() ) : the_post(); 
				            		the_content(); 
				        		endwhile ;
							?>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-8 contact_right">
						<?php echo do_shortcode('[gravityform id=1 title=false description=false ajax=true]');?>
					</div>	
				</div>
			</div>
		</div>
		<div class="contact_google_map">
			<?php echo do_shortcode('[put_wpgm id=1]'); ?>
		</div>
	</section>
</div>
	<!-- <div style="height: 500px;width: 100%;background-color: #ddd;"></div> -->
</main> 

<?php get_footer(); ?>