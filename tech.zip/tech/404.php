<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<main>
		<section class="page_banner" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12">
						<h1>404 Not Found</h1>
					</div>
				</div>
			</div>	
		</section>
			
		<section class="page_content_wrapper">
			<div class="triangle_box">
				<div class="tech_box">
					<span>Why tech?</span>
				</div>
			</div>
				<div class="page_content">
					<div class="container">
						<div class="row">
							<div class="col-xs-12 col-sm-12 col-md-6 col_404">
								<div class="text_404">
									<span>4</span>
									<span>0</span>
									<span>4</span>
								</div>

								<h2 class="blog_head"><?php _e( 'Oops! That page can&rsquo;t be found.', 'twentysixteen' ); ?></h2>
								<p class="margin_bottom_40"><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'twentysixteen' ); ?></p>
								<?php get_search_form(); ?>
							</div>
						</div>
					</div>
				</div>
		</section>	
	</main> 
	
<?php get_footer(); ?>
