<?php 
/*
Template Name: About Us Template
*/
?>
<?php get_header(); ?>
<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>About Us</h2>
				</div>
			</div>
		</div>	
	</section>
	<div class="page_outer">
		<div class="submenu_wrap submenu_minus">
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
			<div class="menu-heading">Menu</div>
		</div>
		
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<?php  echo do_shortcode('[wpb_childpages]'); ?>
			</div>
		</div>	
		<section class="page_content_wrapper">
			<div class="triangle_box">
				<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
				<div class="tech_box">
					<span>Why tech?</span>
				</div>
			</div>
			<div class="page_content">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-4">
							<h1 class="section_head"><?php the_title(); ?></h1>

							<div class="page_vc_content">
								<?php 
									while ( have_posts() ) : the_post(); 
					            		the_content(); 
					        		endwhile ;
								?>
							</div>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-8 text-center">
							<div class="row">
								<div class="col-xs-12 col-sm-12 col-md-6 about_box">
								<?php if( get_field('who_we_are') ): ?>
									<div class="hexabox_wrap hexabox_wrap1" style="background-image: url('<?php the_field('who_we_are'); ?>');">
								<?php else: ?>
									<div class="hexabox_wrap hexabox_wrap1" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/Who-we-are.jpg');">
								<?php endif ; ?>
										<div class="color_overlay"></div>
										<div class="white_overlay"></div>
										<div class="feature_content">
											<div class="feature_text_head">
												<div class="feature_head">
													<a href="<?php the_permalink(168) ?>">Who We Are</a>
												</div>
												<a href="<?php the_permalink(168) ?>"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
											</div>
										</div>						
									</div>
								</div>

								<div class="col-xs-12 col-sm-12 col-md-6 about_box">
									<?php if( get_field('core_values') ): ?>
									<div class="hexabox_wrap hexabox_wrap2" style="background-image: url('<?php the_field('core_values'); ?>');">
									<?php else: ?>
									<div class="hexabox_wrap hexabox_wrap2" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_2.jpg');">
									<?php endif ; ?>
										<div class="color_overlay"></div>
										<div class="white_overlay"></div>
										<div class="feature_content">
											<div class="feature_text_head">
												<div class="feature_head">
													<a href="<?php the_permalink(170) ?>">Core Values</a>
												</div>
												<a href="<?php the_permalink(170) ?>"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
											</div>
										</div>						
									</div>
								</div>
								
								<div class="col-xs-12 col-sm-12 col-md-6 about_box col-md-offset-3">
									<?php if( get_field('contact_us') ): ?>
									<div class="hexabox_wrap hexabox_wrap3" style="background-image: url('<?php the_field('contact_us'); ?>');">
									<?php else: ?>
									<div class="hexabox_wrap hexabox_wrap3" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_3.jpg');">
									<?php endif ; ?>
									
										<div class="color_overlay"></div>
										<div class="white_overlay"></div>
										<div class="feature_content">
											<div class="feature_text_head">
												<div class="feature_head"><a href="<?php the_permalink(76) ?>">Contact Us</a></div>
												<a href="<?php the_permalink(76) ?>"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
											</div>
										</div>						
									</div>
								</div>



							</div>

						</div>	
					</div>
				</div>
			</div>
		</section>
	</div>
	<!-- <div style="height: 500px;width: 100%;background-color: #ddd;"></div> -->
</main> 

<?php get_footer(); ?>