<?php 
function testimonial_slider(){ ?>
    <div class="carousel slide" data-ride="carousel" id="quote-carousel">

        <?php $testimonial = array(
            'post_type' => 'client_testimonial',
            'posts_per_page' => -1,
            'order'     => DESC, 
            'post_status' => 'publish'

        ); 
        $loop = new WP_Query( $testimonial );
        $j=0; ?>


             <!-- Indicators -->
          <ol class="carousel-indicators">
             <?php  while ( $loop->have_posts() ) : $loop->the_post(); ?>
            <li data-target="#quote-carousel" data-slide-to="<?php echo $j ?>" class="<?php if($j==0)echo 'active';?> "></li>
        <?php $j++; endwhile; ?>
          </ol>


        <div class="carousel-inner text-center">
            <?php  
                $i=1;
            while ( $loop->have_posts() ) : $loop->the_post(); ?>
            <div class="item <?php if($i==1)echo 'active';?>">
                <?php //} ?>
                <div class="testimonial_text">
                    <?php the_excerpt(); ?>
                    <a class="rmore-button" href="<?php echo get_permalink( 3001 ).'#testimoid-'.$i; ?>">Read More</a>
                </div>
                <p class="testimonial_author"><?php the_field('client_name'); ?></p>
            </div>
            <?php $i++; endwhile; ?>
        </div>
    </div>

<?php }
add_shortcode("testimonial_slider", "testimonial_slider");

function wpb_list_child_pages() { 
 
global $post; 
 
if ( is_page() && $post->post_parent )
 
    $childpages = wp_list_pages($post->ID);
    //$childpages = wp_list_pages( 'sort_column=menu_order&title_li=&child_of=' . $post->post_parent . '&echo=0' );
else
    $childpages = wp_list_pages( 'sort_column=menu_order&title_li=&child_of=' . $post->ID . '&echo=0' );
    
    $string = '<ul>' ; 

if ( $childpages ) {
 
    $string .= '<li>' . $childpages . '<li>';
}

    $string .= '</ul>';
    
return $string;
 
}
 
add_shortcode('wpb_childpages', 'wpb_list_child_pages');