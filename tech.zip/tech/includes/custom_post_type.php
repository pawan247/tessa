<?php
/*custom post our team*/
function create_our_team() {
    register_post_type( 'team',
        array(
            'labels' => array(
                'name' => 'Team Members',
                'singular_name' => 'Team Member',
                'add_new' => 'Add New Member',
                'add_new_item' => 'Add New Member',
                'edit' => 'Edit',
                'edit_item' => 'Edit Member',
                'new_item' => 'New Member',
                'view' => 'View',
                'view_item' => 'View Member',
                'search_items' => 'Search Member',
                'not_found' => 'No Member found',
                'not_found_in_trash' => 'No Member found in Trash',
                'parent' => 'Parent Member'
            ),
 
            'public' => true,
            'menu_position' => 13,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( '' ),
            'menu_icon' => 'dashicons-universal-access-alt',
            'has_archive' => true
        )
    );
}
add_action( 'init', 'create_our_team' );

function create_our_testimonial() {
    register_post_type( 'testimonial',
        array(
            'labels' => array(
                'name' => 'Testimonials Blurb',
                'singular_name' => 'Testimony',
                'add_new' => 'Add New Testimony',
                'add_new_item' => 'Add New Testimony',
                'edit' => 'Edit',
                'edit_item' => 'Edit Testimony',
                'new_item' => 'New Testimony',
                'view' => 'View',
                'view_item' => 'View Testimony',
                'search_items' => 'Search Testimony',
                'not_found' => 'No Testimony found',
                'not_found_in_trash' => 'No Testimony found in Trash',
                'parent' => 'Parent Testimony'
            ),
 
            'public' => true,
            'menu_position' => 14,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( '' ),
            'menu_icon' => 'dashicons-format-quote',
            'has_archive' => true
        )
    );
}
add_action( 'init', 'create_our_testimonial' );

function create_testimonial_tax() {
    register_taxonomy(
        'testimonial-category',
        'testimonial',
        array(
            'label' => __( 'Categories' ),
            'rewrite' => false,
            'hierarchical' => true,
        )
    );
}
add_action( 'init', 'create_testimonial_tax' );


/*custom post casestudies*/
function create_casestudies() {
    register_post_type( 'casestudies',
        array(
            'labels' => array(
                'name' => 'Case Studies',
                'singular_name' => 'Case Study',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Case Study',
                'edit' => 'Edit',
                'edit_item' => 'Edit Case Study',
                'new_item' => 'New Case Study',
                'view' => 'View',
                'view_item' => 'View Case Study',
                'search_items' => 'Search Case Study',
                'not_found' => 'No Case Study found',
                'not_found_in_trash' => 'No Case Study found in Trash',
                'parent' => 'Parent Case Study'
            ),
 
            'public' => true,
            'menu_position' => 15,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( 'casestudies-cat' ),
            'menu_icon' => 'dashicons-portfolio',
            'has_archive' => true
        )
    );
}
add_action( 'init', 'create_casestudies' );


function create_casestudy_tax() {
    register_taxonomy(
        'casestudies-cat',
        'casestudies',
        array(
            'label' => __( 'Categories' ),
            'rewrite' => false,
            'hierarchical' => true,
            'rewrite' => array('hierarchical' => true, 'slug' => 'casestudies-cat'),
        )
    );
}
add_action( 'init', 'create_casestudy_tax' );


/*custom post casestudies*/
function create_technologies() {
    register_post_type( 'technologies',
        array(
            'labels' => array(
                'name' => 'Technologies',
                'singular_name' => 'Technology',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Technology',
                'edit' => 'Edit',
                'edit_item' => 'Edit Technology',
                'new_item' => 'New Technology',
                'view' => 'View',
                'view_item' => 'View Technology',
                'search_items' => 'Search Technology',
                'not_found' => 'No Technology found',
                'not_found_in_trash' => 'No Technology found in Trash',
                'parent' => 'Parent Technology'
            ),
 
            'public' => true,
            'menu_position' => 16,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( 'technology-category' ),
            'menu_icon' => 'dashicons-screenoptions',
            'has_archive' => true
        )
    );
}
add_action( 'init', 'create_technologies' );


function create_technology_tax() {
    register_taxonomy(
        'technology-category',
        'technologies',
        array(
            'label' => __( 'Categories' ),
            'rewrite' => false,
            'hierarchical' => true,
            'rewrite' => array('hierarchical' => true, 'slug' => 'technology'),
        )
    );
}
add_action( 'init', 'create_technology_tax' );



/*custom post casestudies*/
function create_marketing() {
    register_post_type( 'internet-marketing',
        array(
            'labels' => array(
                'name' => 'Marketing',
                'singular_name' => 'Marketing',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Market',
                'edit' => 'Edit',
                'edit_item' => 'Edit Market',
                'new_item' => 'New Market',
                'view' => 'View',
                'view_item' => 'View Market',
                'search_items' => 'Search Market',
                'not_found' => 'No Market found',
                'not_found_in_trash' => 'No Market found in Trash',
                'parent' => 'Parent Market'
            ),
 
            'public' => true,
            'menu_position' => 17,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( 'marketing-category' ),
            'menu_icon' => 'dashicons-groups',
            'has_archive' => true
        )
    );
}
add_action( 'init', 'create_marketing' );


function create_marketing_tax() {
    register_taxonomy(
        'marketing-category',
        'internet-marketing',
        array(
            'label' => __( 'Categories' ),
            'rewrite' => false,
            'hierarchical' => true,
            'rewrite' => array('hierarchical' => true, 'slug' => 'marketing'),
        )
    );
}
add_action( 'init', 'create_marketing_tax' );


function create_client_testimonial() {
    register_post_type( 'client_testimonial',
        array(
            'labels' => array(
                'name' => 'Client Testimonials',
                'singular_name' => 'Client Testimonials',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Testimonials',
                'edit' => 'Edit',
                'edit_item' => 'Edit Testimonials',
                'new_item' => 'New Testimonials',
                'view' => 'View',
                'view_item' => 'View Testimonials',
                'search_items' => 'Search Testimonials',
                'not_found' => 'No Testimonials found',
                'not_found_in_trash' => 'No Testimonials found in Trash',
                'parent' => 'Parent Testimonials'
            ),
 
            'public' => true,
            'menu_position' => 17,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( 'testimonials-category' ),
            'menu_icon' => 'dashicons-format-status',
            'has_archive' => true
        )
    );
}
add_action( 'init', 'create_client_testimonial' );


function client_testimonial_tax() {
    register_taxonomy(
        'testimonials-category',
        'client_testimonial',
        array(
            'label' => __( 'Categories' ),
            'rewrite' => false,
            'hierarchical' => true,
            'rewrite' => array('hierarchical' => true, 'slug' => 'client_testimonial'),
        )
    );
}
add_action( 'init', 'client_testimonial_tax' );

/* custom post type for Awards */

function award_custom_post() {
    register_post_type( 'award',
        array(
            'labels' => array(
                'name' => 'Awards',
                'singular_name' => 'Client Awards',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Awards',
                'edit' => 'Edit',
                'edit_item' => 'Edit Awards',
                'new_item' => 'New Awards',
                'view' => 'View',
                'view_item' => 'View Awards',
                'search_items' => 'Search Awards',
                'not_found' => 'No Awards found',
                'not_found_in_trash' => 'No Awards found in Trash',
                'parent' => 'Parent Awards'
            ),
 
            'public' => true,
            'menu_position' => 17,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( 'testimonials-category' ),
            'menu_icon' => 'dashicons-awards',
            'has_archive' => true
        )
    );
}
add_action( 'init', 'award_custom_post' );


function award_custom_post_tax() {
    register_taxonomy(
        'awards-category',
        'awards',
        array(
            'label' => __( 'Categories' ),
            'rewrite' => false,
            'hierarchical' => true,
            'rewrite' => array('hierarchical' => true, 'slug' => 'awards'),
        )
    );
}
add_action( 'init', 'award_custom_post_tax' );
 
/* End code for custom post type */
