<?php 
/*
Template Name: Front Page Template
*/
?>
<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<main>
	<section class="slider_section">
		<div class="home_slider">
			<div class="home_slider_slide">
				<?php putRevSlider("new-slider", "home") ?>
			</div>
		</div>
	</section>

	<section class="intro_section">
		<div class="green_box">
			<div class="black_box"></div>
			<div class="green_box_neutral">	
				<div class="green_box_text box_text">
					<h2><?php the_field('left_area_title'); ?></h2>
					<h4><?php the_field('left_area_description'); ?></h4>
					<ul>
						<li><a href="<?php the_field('link_one'); ?>"><?php the_field('1_name'); ?></a></li>
						<li><a href="<?php the_field('link_two'); ?>"><?php the_field('2_name'); ?></a></li>
						<li><a href="<?php the_field('link_three'); ?>"><?php the_field('3_name'); ?></a></li>
						<li><a href="<?php the_field('link_four'); ?>"><?php the_field('4_name'); ?></a></li>
						<li><a href="<?php the_field('link_five'); ?>"><?php the_field('5_name'); ?></a></li>
						<li><a href="<?php the_field('link_six'); ?>"><?php the_field('6_name'); ?></a></li>
						<li><a href="<?php the_field('link_seven'); ?>"><?php the_field('7_name'); ?></a></li>
						<li><a href="<?php the_field('link_eight'); ?>"><?php the_field('8_name'); ?></a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="blue_box">
			<div class="blue_box_neutral">			
				<div class="blue_box_text box_text hello">
					<h2><?php the_field('right_area_title'); ?></h2>
					<h4><?php the_field('right_area_description'); ?></h4>
					<div class="newsletter_form_wrapper">
						<form action="" method="" class="newsletter_form" id="myform">
							<input type="text" name="emailId" id="emailId" placeholder="Enter your URL to get started">
							<input type="button" value="SUBMIT" class="newsletter_submit" />
						</form>
						<div class="validation_text_wrapper"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- <div class="black_box"></div> -->
	</section>

	<section class="feature_section">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-4">
				<?php if( get_field('image') ): ?>

					<img src="<?php the_field('image'); ?>" />

				<?php endif; ?>
					<?php 
						$first_image = get_field('first_blurb_image');
					?>
					<div class="hexabox_wrap hexabox_wrap1" style="background-image: url(<?php echo $first_image ?>);">
						<div class="color_overlay"></div>
						<div class="white_overlay"></div>
						<div class="feature_content" onclick="">
							<div class="feature_text_head">
								<div class="feature_head"><?php the_field('first_blurb_heading'); ?></div>
								<p class=""><?php the_field('first_blurb_subheading'); ?></p>
								<i class="fa fa-angle-right feature_click" aria-hidden="true"></i>
							</div>
						</div>
						<div class="feature_click_wrap">
							<h2><?php the_field('first_blurb_subheading'); ?></h2>
							<p><?php $first_desc = get_field('first_blurb_description'); 
								echo substr(strip_tags($first_desc),0,100).'...';
							?></p>
							<a href="<?php the_field('first_blurb_link'); ?>"><i class="fa fa-angle-right feature_click" aria-hidden="true"></i></a>
						</div>						
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-4">
					<?php 
						$second_image = get_field('second_blurb_image');
					?>
					<div class="hexabox_wrap hexabox_wrap2" style="background-image: url(<?php echo $second_image ?>);">
						<div class="color_overlay"></div>
						<div class="white_overlay"></div>
						<div class="feature_content" onclick="">
							<div class="feature_text_head">
								<div class="feature_head"><?php the_field('second_blurb_heading'); ?></div>
								<p class=""><?php the_field('second_blurb_subheading'); ?></p>
								<i class="fa fa-angle-right feature_click" aria-hidden="true"></i>								
							</div>
						</div>                  
						<div class="feature_click_wrap">
							<h2><?php the_field('second_blurb_subheading'); ?></h2>
							<p>
							<?php $sec_desc = get_field('second_blurb_description'); 
								echo substr(strip_tags($sec_desc),0,100).'...';
							?></p>
							<a href="<?php the_field('second_blurb_link'); ?>"><i class="fa fa-angle-right feature_click" aria-hidden="true"></i></a>
						</div>						
					</div>				
				</div>
				<div class="col-xs-12 col-sm-12 col-md-4">
					<?php 
						$third_image = get_field('third_blurb_image');
					?>
					<div class="hexabox_wrap hexabox_wrap3" style="background-image: url(<?php echo $third_image ?>);">
						<div class="color_overlay"></div>						
						<div class="white_overlay"></div>
						<div class="feature_content" onclick="">
							<div class="feature_text_head">
								<div class="feature_head"><?php the_field('third_blurb_heading'); ?></div>
								<p class=""><?php the_field('third_blurb_subheading'); ?></p>
								<i class="fa fa-angle-right feature_click" aria-hidden="true"></i>	
							</div>
						</div>
						<div class="feature_click_wrap">
							<h2><?php the_field('third_blurb_subheading'); ?></h2>
							<p><?php $third_desc = get_field('third_blurb_description'); 
								echo substr(strip_tags($third_desc),0,100).'...';
							?></p>							
							<a href="<?php the_field('third_blurb_link'); ?>"><i class="fa fa-angle-right feature_click" aria-hidden="true"></i></a>
						</div>
					</div>				
				</div>
			</div>
		</div>	
	</section>

	<section class="specialty_section">
		<div class="book_click_button"></div>

		<i class="fa fa-angle-left book_left"></i>
		<i class="fa fa-angle-right book_right"></i>	

		<div class="specialty_left specialty_col">
			<!-- <div class="orange_shadow"></div> -->
			<!-- <h2 class="slider_title">Disciplined</h2> -->
		</div>
		<div class="specialty_right specialty_col">
			<!-- <div class="blue_shadow"></div> -->
			<!-- <h2 class="slider_title">Determined</h2> -->
		</div>

		<div class="specialty_slider_wrap">
			<div class="specialty_slide to_left">
				<?php if(get_field('first_slide_left_heading')): ?>
					<div class="slide_child normal_text"><span><?php the_field('first_slide_left_heading'); ?></span></div>
				<?php endif; ?>
			</div>		
 			<div class="specialty_slide to_right slide_index z_index_99">
				<?php if(get_field('first_slide_right_heading')): ?>
					<div class="slide_child normal_text child_show"><span><?php the_field('first_slide_right_heading'); ?></span></div>
				<?php endif; ?>
				<?php if(get_field('second_slide_left_heading')): ?>
					<div class="slide_child flip_text child_hide"><span><?php the_field('second_slide_left_heading'); ?></span></div>
				<?php endif; ?>
			</div>
			<div class="specialty_slide to_right">
				<?php if(get_field('second_slide_right_heading')): ?>
					<div class="slide_child normal_text child_show"><span><?php the_field('second_slide_right_heading'); ?></span></div>
				<?php endif; ?>
				<?php if(get_field('third_slide_left_heading')): ?>
					<div class="slide_child flip_text child_hide"><span><?php the_field('third_slide_left_heading'); ?></span></div>
				<?php endif; ?>
			</div>		
			<div class="specialty_slide to_right">
				<?php if(get_field('third_slide_right_heading')): ?>
					<div class="slide_child normal_text child_show"><span><?php the_field('third_slide_right_heading'); ?></span></div>
				<?php endif; ?>
				<?php if(get_field('fourth_slide_left_heading')): ?>
					<div class="slide_child flip_text child_hide"><span><?php the_field('fourth_slide_left_heading'); ?></span></div>
				<?php endif; ?>
			</div>
			<div class="specialty_slide to_right">
				<?php if(get_field('fourth_slide_right_heading')): ?>
					<div class="slide_child normal_text child_show"><span><?php the_field('fourth_slide_right_heading'); ?></span></div>
				<?php endif; ?>
				<?php if(get_field('fifth_slide_left_heading')): ?>
					<div class="slide_child flip_text child_hide"><span><?php the_field('fifth_slide_left_heading'); ?></span></div>
				<?php endif; ?>
			</div>		
			<div class="specialty_slide to_right">
				<?php if(get_field('fifth_slide_right_heading')): ?>
					<div class="slide_child normal_text child_show"><span><?php the_field('fifth_slide_right_heading'); ?></span></div>
				<?php endif; ?>
				<?php if(get_field('sixth_slide_left_heading')): ?>
					<div class="slide_child flip_text child_hide"><span><?php the_field('sixth_slide_left_heading'); ?></span></div>
				<?php endif; ?>
			</div>	
			<div class="specialty_slide to_right">
				<?php if(get_field('sixth_slide_right_heading')): ?>
					<div class="slide_child normal_text child_show"><span><?php the_field('sixth_slide_right_heading'); ?></span></div>
				<?php endif; ?>
				<?php if(get_field('seventh_slide_left_heading')): ?>
					<div class="slide_child flip_text child_hide"><span><?php the_field('seventh_slide_left_heading'); ?></span></div>
				<?php endif; ?>
			</div>				
			<div class="specialty_slide to_right">
				<?php if(get_field('seventh_slide_right_heading')): ?>
					<div class="slide_child normal_text"><span><?php the_field('seventh_slide_right_heading'); ?></span></div>
				<?php endif; ?>
			</div>			
		</div>

		<div class="slider_click_outer">
			<div class="specialty_slider_text_wrap">
				<div class="specialty_slider_text_left"></div>
				<div class="specialty_slider_text_right"></div>
			</div>

			<div class="slider_click_text">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 text-center">
							<h2></h2>
							<p></p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="click_text_wrap">
		<?php if(get_field('first_slide_description')): ?>
			<div class="click_text text_1"><?php the_field('first_slide_description') ?></div>
		<?php endif; ?>
		<?php if(get_field('second_slide_description')): ?>
			<div class="click_text text_2"><?php the_field('second_slide_description') ?></div>
		<?php endif; ?>
		<?php if(get_field('third_slide_description')): ?>
			<div class="click_text text_3"><?php the_field('third_slide_description') ?></div>
		<?php endif; ?>
		<?php if(get_field('fourth_slide_description')): ?>
			<div class="click_text text_4"><?php the_field('fourth_slide_description') ?></div>
		<?php endif; ?>
		<?php if(get_field('fifth_slide_description')): ?>
			<div class="click_text text_5"><?php the_field('fifth_slide_description') ?></div>
		<?php endif; ?>
		<?php if(get_field('sixth_slide_description')): ?>
			<div class="click_text text_6"><?php the_field('sixth_slide_description') ?></div>
		<?php endif; ?>
		<?php if(get_field('seventh_slide_description')): ?>
			<div class="click_text text_6"><?php the_field('seventh_slide_description') ?></div>
		<?php endif; ?>
		</div>
	</section>

	<div class="client_head_wrap">
		<h2 class="client_head"><?php the_field('clients_heading'); ?></h2>
	</div>

	<section class="client_section">
	<?php 
		
		$args = array(
				'posts_per_page' => 12,
				'post_type' => 'casestudies',
				'meta_key'	=> 'show_on_home',
				'meta_value' => 'Yes'
		);

		$the_query = new WP_Query($args);

		$count = $the_query->post_count; 

		if($count == 0 || $count<12){
			//echo 'fgd';
			$args = array(
				'posts_per_page' => 12,
				'post_type' => 'casestudies',
			);

			$query_not_at_home = new WP_Query($args);

		}

		if($count == 0 || $count<12) : 
	?>
			<?php if( $query_not_at_home->have_posts() ): ?>

				<div class="client_left client_col">
					<ul class="client_list client_list_left">
					<?php $i = 0 ; while( $query_not_at_home->have_posts() ) : $query_not_at_home->the_post();  ?>
						<li>
							<a href="<?php the_permalink(); ?>">
								<?php $logo = get_field('logo'); 
									$client_name = get_field('client_name') ;
									if($logo) { ?>
									<img src="<?php the_field('logo'); ?>" alt="" />
								<?php } else { ?>
									<img src="<?php echo get_stylesheet_directory_uri()?>/images/home/client_logo.png" alt="" />
								<?php } ?>
								<?php if($client_name) { ?>
								<h2 class=""><span><?php the_field('client_name'); ?></span> <i class="fa fa-angle-double-right" aria-hidden="true"></i></h2>
								<?php } else { ?>
								<h2 class=""><span>Bechtel</span> <i class="fa fa-angle-double-right" aria-hidden="true"></i></h2>
								<?php } ?>
							</a>
						</li>
					<?php $i++; 
					if($i==6){ ?>
					</ul>
				</div>
				<div class="client_right client_col">
					<ul class="client_list client_list_right">
					<?php }
					endwhile; ?>						
					</ul>
				</div>
			<?php endif; ?>
		
		<?php else : ?>

			<?php if( $the_query->have_posts() ): ?>

				<div class="client_left client_col">
					<ul class="client_list client_list_left">
					<?php $i = 0 ; while( $the_query->have_posts() ) : $the_query->the_post();  ?>
						<li>
							<a href="<?php the_permalink(); ?>">
								<?php $logo = get_field('logo'); 
									$client_name = get_field('client_name') ;
									if($logo) { ?>
									<img src="<?php the_field('logo'); ?>" alt="" height="150" width="150" />
								<?php } else { ?>
									<img src="<?php echo get_stylesheet_directory_uri()?>/images/home/client_logo.png" alt="" />
								<?php } ?>
								<?php if($client_name) { ?>
								<h2 class=""><span><?php the_field('client_name'); ?></span> <i class="fa fa-angle-double-right" aria-hidden="true"></i></h2>
								<?php } else { ?>
								<h2 class=""><span>Bechtel</span> <i class="fa fa-angle-double-right" aria-hidden="true"></i></h2>
								<?php } ?>
							</a>
						</li>
					<?php $i++; 
					if($i==6){ ?>
					</ul>
				</div>
				<div class="client_right client_col">
					<ul class="client_list client_list_right">
					<?php }
					endwhile; ?>						
					</ul>
				</div>
			<?php endif; ?>

		<?php endif ;  ?>
	<?php wp_reset_query();	 // Restore global post data stomped by the_post(). ?>
	</section>
</main> 

<?php get_footer(); ?>