<?php 
/*
Template Name: Casestudies Template
*/
?>
<?php get_header(); ?>
<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Case Studies</h2>
				</div>
			</div>
		</div>	
	</section>
		
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-6">
						<h1 class="section_head"><?php the_title(); ?></h1>
						<div class="page_vc_content">
							<?php 
								while ( have_posts() ) : the_post(); 
				            		the_content(); 
				        		endwhile ;
							?>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6 text-center">
						<div class="industry_col">
							<?php 
							$categories = get_terms(
							array('casestudies-cat'),
							array(
							        'hide_empty'    => false,
							        'orderby'       => 'title',
							        'order'         => 'ASC'
							    )
							);
							
							//print_r($categories); ?>
							<div class="industry_row">
								<?php $row = 1;
									$count =  1;
								foreach ($categories as $key => $value) { 
									$row%2!=0 ? $check=3 : $check=2; 
									$term_link = get_term_link($value->term_id , 'casestudies-cat' );
									if($count == $check){ 
										 ?>
										
											<div class="industry_hexagon_wrap">
												<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
													<div class="industry_color_overlay"></div>
													<a href="<?php echo $term_link; ?>" class="industry_text"><?php echo $value->name; ?></a>
												</div>
											</div>
										
										<?php 
											$count = 1; 
											$row++; 
										?>
									</div><div class="industry_row">
									<?php  } else { ?>
											<div class="industry_hexagon_wrap">
													<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
														<div class="industry_color_overlay"></div>

														<a href="<?php echo $term_link; ?>" class="industry_text"><?php echo $value->name; ?></a>
													</div>
											</div>
									
									<?php $count += 1; }
								} ?>
							</div>
						</div>
					</div>	
				</div>
			</div>
		</div>
	</section>	
	<!-- <div style="height: 500px;width: 100%;background-color: #ddd;"></div> -->
</main> 

<?php get_footer(); ?>