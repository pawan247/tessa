<?php get_header(); ?>
<main>
<?php 
$term = get_queried_object();
$term_id = $term->term_id;
$term_name = $term->name;
$taxonomy_name = $term->taxonomy;
$term_description = $term->description;
?>
	<?php if( get_field('banner_image',6) ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image',6); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Case Studies</h2>
				</div>
			</div>
		</div>	
	</section>
		

	<div class="page_outer">
		<div class="submenu_wrap submenu_minus">
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
			<div class="menu-heading">Menu</div>
		</div>
		<?php 
			$categories = get_terms(
						array('casestudies-cat'),
						array(
						        'hide_empty'    => false,
						        'orderby'       => 'title',
						        'order'         => 'ASC'
						    )
						);
			//print_r($categories);
		?>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<ul>
				<?php foreach ($categories as $key => $value) { 
						$term_link = get_term_link($value->term_id , 'casestudies-cat' );
					?>
					<li><a href="<?php echo $term_link ?>"><?php echo $value->name; ?></a></li>
					
				<?php } ?>
				</ul>
			</div>
		</div>
		<section class="page_content_wrapper">
			<div class="triangle_box">
				<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
				<div class="tech_box">
					<span>Why tech?</span>
				</div>

				<div class="hexagon_title_box">
					<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
						<div class="industry_color_overlay" style="background-color: rgba(0, 137, 207, 0.8);"></div>
						<div class="industry_text"><?php echo $term_name; ?></div>
					</div>
				</div>
				
			</div>

			<div class="hexagon_title_box">
					<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
						<div class="industry_color_overlay" style="background-color: rgba(0, 137, 207, 0.8);"></div>
						<div class="industry_text"><?php echo $term_name; ?></div>
					</div>
			</div>

			<div class="page_content">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-8">
							<h1 class="section_head margin_bottom_40"><?php echo $term_name; ?></h1>
							<div class="cat_descr page_vc_content"><?php echo $term_description; ?></div>
						</div>
						<?php 
							$myposts=array(
							'post_type' => 'casestudies',
							'posts_per_page' => -1,
							'tax_query' => array(
									array(
										'taxonomy' => 'casestudies-cat',
										'field' => 'term_id',
										'terms' => $term_id)
										)
								);
							$loop = new WP_Query( $myposts );
							//echo '<pre>';
							//print_r($loop);
						?>
						<div class="col-xs-12 col-sm-12 col-md-4">
							<div class="margin_bottom_30">
								<?php if ( $loop->have_posts() ): ?>
									<ul class="detail_list">
								<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
										<li>
											<a href="<?php the_permalink(); ?>">
												<h2><?php the_title(); ?></h2>
												<p><?php the_field('sub_heading',$post->ID); ?></p>
											</a>
										</li>
								<?php endwhile; ?>
									</ul>
								<?php endif; ?>				
								<!-- </div> -->
								<?php wp_reset_postdata();  ?>
							</div>
						</div>	
					</div>
				</div>
			</div>
		</section>	
	</div>
</main> 
<?php get_footer(); ?>