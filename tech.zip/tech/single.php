<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<main>

	<?php if( get_field('banner_image',12) ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image',12); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h1><?php the_title(); ?></h1>
				</div>
			</div>
		</div>	
	</section>
		
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-8 col-md-9">
						<div class="row">
							<?php while ( have_posts() ) : the_post(); ?>
								<?php /*$gallery = get_post_gallery( $post->ID, false ); if($gallery):*/ ?>
								<?php $attachments = new Attachments( 'attachments' ); /* pass the instance name */ ?>
								<?php if( $attachments->exist() ) : ?>
									<div class="col-xs-12 col-sm-12 col-md-12 margin_bottom_60">
										<div class="featured_slider_outer">
											<i class="fa fa-angle-left feat_previous"></i>
											<i class="fa fa-angle-right feat_next"></i>
											<div class="featured_slider">
												<?php while( $attachments->get() ) : ?>
													<img src="<?php echo $attachments->src( 'full' ); ?>" alt="" width="50%" />
												<?php endwhile; ?>
											</div>
										</div>
									</div>
								<?php else: ?>
									<?php if(has_post_thumbnail()) : ?>	
										<div class="col-xs-12 col-sm-12 col-md-12 margin_bottom_60">
											<img src="<?php echo get_the_post_thumbnail_url(); ?>" width="50%"/>
										</div>
									<?php endif ; ?>
								<?php endif; ?>
							
							
							<div class="col-xs-12 col-sm-12 col-md-12 margin_bottom_20">
								<div class="page_vc_content">
									<p class="margin_bottom_0 blog_date_time"><?php the_time('F jS, Y') ?></p>
									<?php  
									 	 //$content = strip_shortcode_gallery( get_the_content() );
									 	 //echo $content;
										the_content();
									?>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 margin_bottom_20">
								<ul class="blog_social_list">
									<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('https://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>')"><img src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/facebook_black.png"></a></li>
									<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('https://twitter.com/share?text=<?php the_title(); ?>&url=<?php the_permalink();?>')"><img src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/twitter_black.png"></a></li>
									<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('https://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title(); ?>&url=<?php the_permalink(); ?>')"><img src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/linked_in_black.png"></a></li>
									<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('https://plus.google.com/share?url=<?php the_permalink(); ?>')"><img src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/google_plus_black.png"></a></li>
									<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>')"><img src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/pinterest_black.png"></a></li>
								</ul>

							</div>
						<?php endwhile; ?>
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-3">
						<?php get_sidebar('blogs'); ?>
					</div>	
				</div>
			</div>
		</div>
	</section>	

</main> 

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
