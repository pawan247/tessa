<?php 
/*
Template Name: SEO Template
*/
?>
<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header('campaign'); ?>

<main>

	<section class="seo_banner">
	<?php if( get_field('banner_image') ): ?>
		<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else : ?>
		<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri() ?>/images/seo/seo_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6 col-md-offset-6">
					<?php 
						while ( have_posts() ) : the_post(); 
		            		the_content(); 
		        		endwhile ;
					?>
				</div>
			</div>
		</div>
	</section>

	<section class="seo_green_box">
		<div class="seo_green_angle_box"></div>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 seo_left">
					<div class="seo_green_neutral seo_left_neutral">
						<h2><?php the_field('first_section_heading'); ?></h2>
						<p><?php the_field('first_section_description'); ?></p>

						<ul>
							<li><a href="<?php the_field('link_one'); ?>"><?php the_field('1_name'); ?></a></li>
							<li><a href="<?php the_field('link_two'); ?>"><?php the_field('2_name'); ?></a></li>
							<li><a href="<?php the_field('link_three'); ?>"><?php the_field('3_name'); ?></a></li>
							<li><a href="<?php the_field('link_four'); ?>"><?php the_field('4_name'); ?></a></li>
							<li><a href="<?php the_field('link_five'); ?>"><?php the_field('5_name'); ?></a></li>
							<li><a href="<?php the_field('link_six'); ?>"><?php the_field('6_name'); ?></a></li>
							<li><a href="<?php the_field('link_seven'); ?>"><?php the_field('7_name'); ?></a></li>
							<li><a href="<?php the_field('link_eight'); ?>"><?php the_field('8_name'); ?></a></li>
						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 seo_right">
					<div class="seo_green_neutral">
						<div class="form">
							<?php echo do_shortcode('[gravityform id=2 title=false description=false ajax=true]'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="seo_white_box">
		<div class="seo_white_angle_box"></div>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6 seo_left">
					<div class="seo_white_neutral">
						<h2><?php the_field('second_section_heading'); ?></h2>
						<p><?php the_field('second_section_description'); ?></p>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 seo_right">
					<div class="seo_white_neutral">
						<ul class="seo_hexabox_list">
							<li>
								<div class="seo_hexabox">
									<div class="black_overlay"></div>
									<div class="seo_hexabox_text" onclick="">
										<h2><?php the_field('first_service'); ?></h2>
									</div>
								</div>
							</li>
							<li>
								<div class="seo_hexabox">
									<div class="black_overlay"></div>
									<div class="seo_hexabox_text" onclick="">
										<h2><?php the_field('second_service'); ?></h2>
									</div>
								</div>
							</li>
							<li>
								<div class="seo_hexabox">
									<div class="black_overlay"></div>
									<div class="seo_hexabox_text" onclick="">
										<h2><?php the_field('third_service'); ?></h2>
									</div>
								</div>
							</li>
							<li>
								<div class="seo_hexabox">
									<div class="black_overlay"></div>
									<div class="seo_hexabox_text" onclick="">
										<h2><?php the_field('fourth_service'); ?></h2>
									</div>
								</div>
							</li>
							<li>
								<div class="seo_hexabox">
									<div class="black_overlay"></div>
									<div class="seo_hexabox_text" onclick="">
										<h2><?php the_field('fifth_service'); ?></h2>
									</div>
								</div>
							</li>	
							<li>
								<div class="seo_hexabox">
									<div class="black_overlay"></div>
									<div class="seo_hexabox_text" onclick="">
										<h2><?php the_field('sixth_service'); ?></h2>
									</div>
								</div>
							</li>														
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="consultation_section">
		<div class="seo_blue_angle_box"></div>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-8 col-md-8 consultation_left">
					<div class="consultation_neutral">
						<?php the_field('content'); ?>
					</div>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4 consultation_right">
					<div class="consultation_neutral">
						<a class="get_free_consultation_form cursor_pointer">GET MY FREE CONSULTATION</a>
						<?php $phn = get_option('my_phone'); 
								$phn_arr = explode('.', $phn);
								$tel = implode('', $phn_arr);
						?>
						<p>Or call <a href="tel:<?php echo $tel; ?>"><?php echo get_option('my_phone') ?></a></p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="seo_feature_wrap">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 text-center">
					<h2 class="seo_feature_head"><?php the_field('testimonials_heading'); ?></h2>
				</div>
			</div>
			<?php 
			$args = array( 'post_type' => 'testimonial', 
			'tax_query' => array( 
				array( 'taxonomy' => 'testimonial-category', 'field' => 'id', 'terms' => 87 ) ) ); 
			$query = new WP_Query( $args );
			if( $query->have_posts() ): ?>

			<div class="row seo_feature_row">
				<?php while( $query->have_posts() ) : $query->the_post(); ?>
					<div class="col-xs-12 col-sm-4 col-md-4 seo_feature_col_wrap">
						<div class="seo_feature_col">
							<?php if(has_post_thumbnail()) : ?>	
								<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" />
							<?php else : ?>
								<img src="" alt="No Image" />
							<?php endif ; ?>
								<h2><?php the_title(); ?></h2>
								<?php the_content(); ?>
						</div>
					</div>
				<?php endwhile; ?>

			<?php endif ; ?>
			<?php wp_reset_query(); ?>
			</div>
		</div>
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="seo_client_logo">
						<div class="seo_case_link">
							<div class="green_overlay"></div>
							<p><a href="<?php the_permalink(6) ?>">READ OUR CASE STUDIES <span>&gt;</span></a></p>
						</div>
						<ul>

						<?php 
		
						$args = array(
								'posts_per_page' => 6,
								'post_type' => 'casestudies',
								'meta_key'	=> 'show_on_campaign',
								'meta_value' => 'Yes'
						);

						$the_query = new WP_Query($args);

						$count = $the_query->post_count; 

						if($count == 0 || $count<6){
							//echo 'fgd';
							$args = array(
								'posts_per_page' => 6,
								'post_type' => 'casestudies',
							);

							$query_not_at_camp= new WP_Query($args);

						}

						if($count == 0 || $count<6) : 

						 if( $query_not_at_camp->have_posts() ): 

							while( $query_not_at_camp->have_posts() ) : $query_not_at_camp->the_post();  ?>
					?>
							<li>
								<a href="<?php the_permalink(); ?>">
								<?php $logo = get_field('logo'); 
									$client_name = get_field('client_name') ;
									if($logo) { ?>
									<img src="<?php the_field('logo'); ?>" alt="" />
								<?php } else { ?>
									<img src="" alt="No Image" />
								<?php } ?>
								</a>
							</li>
							
						<?php endwhile ; ?>
					<?php endif ; 

					else : 

					while( $the_query->have_posts() ) : 
						$the_query->the_post();  ?> 
					<li>
						<a href="<?php the_permalink(); ?>">
						<?php $logo = get_field('logo'); 
							$client_name = get_field('client_name') ;
							if($logo) { ?>
							<img src="<?php the_field('logo'); ?>" alt="" />
						<?php } else { ?>
							<img src="" alt="No Image" />
						<?php } ?>
						</a>
					</li>
					<?php 
					endwhile;
					endif ; ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="seo_footer_top">
		<img src="<?php echo get_stylesheet_directory_uri() ?>/images/seo/tech_logo_color.png" alt="" />
		<div class="seo_footer_left"></div>
		<div class="seo_footer_right"></div>
	</section>
</main> 

<?php get_footer('campaign'); ?>