<?php 
/*
Template Name: Technology Template
*/
?>
<?php get_header(); ?>
<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Technology</h2>
				</div>
			</div>
		</div>	
	</section>
		
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row margin_bottom_40">
					<div class="col-xs-12 col-sm-12 col-md-6">
						<h1 class="section_head"><?php the_title(); ?></h1>
						<div class="page_vc_content margin_bottom_40">
							<?php 
								while ( have_posts() ) : the_post(); 
				            		the_content(); 
				        		endwhile ;
							?>
						</div>
						<div class="tech_logo technology-logo">
							<?php

									// check if the repeater field has rows of data
									if( have_rows('technology_award_logo') ): ?>
							<ul>
								<?php while ( have_rows('technology_award_logo') ) : the_row(); ?>
								<li>
									<img src="<?php  the_sub_field('image'); ?>" alt="" />
								</li>
							<?php endwhile; endif; ?>
							<!-- 	<li>
									<img src="https://tech.tech/wp-content/uploads/2017/09/Gettysburg-museum-history-1.jpg" alt="" />
								</li>								
								<li>
									<img src="https://tech.tech/wp-content/uploads/2017/09/Dominion-Legal-Logo-2.jpg" alt="" />
								</li>
								<li>
									<img src="https://tech.tech/wp-content/uploads/2017/09/altland-house.jpg" alt="" />
								</li> -->
								
							</ul>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6 text-center">
						<div class="industry_col">
							<?php 
							$categories = get_terms(
							array('technology-category'),
							array(
							        'hide_empty'    => false,
							        'orderby'       => 'title',
							        'order'         => 'ASC'
							    )
							);
							
							//print_r($categories); ?>
							<div class="industry_row">
								<?php $row = 1;
									$count =  1;
								foreach ($categories as $key => $value) { 
									$row%2!=0 ? $check=3 : $check=2; 
									$term_link = get_term_link($value->term_id , 'technology-category' );
									if($count == $check){ 
										 ?>
										
											<div class="industry_hexagon_wrap">
												<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
													<div class="industry_color_overlay"></div>
													<a href="<?php echo $term_link; ?>" class="industry_text"><?php echo $value->name; ?></a>
												</div>
											</div>
										
										<?php 
											$count = 1; 
											$row++; 
										?>
									</div><div class="industry_row">
									<?php  } else { ?>
											<div class="industry_hexagon_wrap">
													<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
														<div class="industry_color_overlay"></div>

														<a href="<?php echo $term_link; ?>" class="industry_text"><?php echo $value->name; ?></a>
													</div>
											</div>
									
									<?php $count += 1; }
								} ?>
							</div>
						</div>
					</div>	
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="tp-caption rev_layer_in_column" id="slide-19-layer-5" style="z-index: 35; white-space: normal; font-size: 40px; line-height: 40px; font-weight: 700; color: rgb(0, 137, 207); display: block; font-family: Cairo; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 10px 0px 0px; padding: 0px 30px; letter-spacing: 0px; min-height: 0px; min-width: 100%; max-height: none; max-width: 100%; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; text-align: center;">DC's Leading Website Designers &amp; Developers </div>
						<div class="tp-caption rev_layer_in_column rs-toggle-content-active" style="z-index: 34; white-space: normal; font-size: 40px; line-height: 40px; font-weight: 200; color: rgba(0, 0, 0, 0.75); display: block; font-family: Cairo; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 12px 0px 0px; padding: 0px 30px; letter-spacing: 0px; min-height: 0px; min-width: 100%; max-height: none; max-width: 100%; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; text-align: center;">See some examples of our work: </div>
						<?php 
						echo do_shortcode('[waving width="100%" theme="light" all="0" showCat="true" /]');
						//putRevSlider("WebDev-Projects") ?>
					</div>
				</div>
			</div>
		</div>
	</section>	
	<!-- <div style="height: 500px;width: 100%;background-color: #ddd;"></div> -->
</main> 

<?php get_footer(); ?>