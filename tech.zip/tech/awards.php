<?php 
/*
Template Name: award template
*/

?>

<?php get_header(); ?>
<main>

	<?php if( get_field('banner_image',8) ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image',8); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Awards</h2>
				</div>
			</div>
		</div>	
	</section>
		

	<div class="page_outer">
		<div class="submenu_wrap submenu_minus">
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
			<div class="menu-heading">Menu</div>
		</div>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				
			</div>
		</div>
		<section class="page_content_wrapper">
			<div class="triangle_box">
				<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
				<div class="tech_box">
					<span>Why tech?</span>
				</div>
				
			</div>
			<div class="page_content">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-8">
						<h1>Internet Marketing Awards</h1>
							<?php 
							$awards = array(
								'post_type' => 'award',
								'post_per_page' => 10,
							);
							$query_result = New Wp_Query($awards); ?>

							<div class="row">
								<?php while($query_result->have_posts()): $query_result->the_post();
								$headerImageUrl = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'full' ); 

								?>
									<div class="col-sm-6">
										<div class="awards_wrapper">
										
											<div class="award_img" style="background-image: url('<?php echo $headerImageUrl; ?>');"></div>

											<!-- <img src="" alt="" width="100%" /> -->
											<a href="<?php the_permalink(); ?>">
												<div class="awards_text">
													<div class="awards_text_mid">
														<h2><?php the_title(); ?></h2>
														<p><?php echo wp_trim_words( get_the_content(), 15, '...' ); ?></p>
														<?php
														$category = get_the_terms( $post->ID, 'testimonials-category' );     
															foreach ( $category as $cat){
															   echo $cat->name;
															} //echo $category_detail; ?>
													</div>
												</div>
											</a>
										</div>
									</div>
								<?php endwhile; ?>
							</div>

						</div>
						
						<div class="col-xs-12 col-sm-12 col-md-4">
							<?php echo do_shortcode('[testimonial_slider]'); ?>
						
						</div>	
					</div>
					
				</div>
			</div>
		</section>	
	</div>
</main> 
<?php get_footer(); ?>