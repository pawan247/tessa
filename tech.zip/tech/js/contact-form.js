jQuery(function( $ ){

	jQuery( "#gform_1 .gform_footer" ).insertAfter( jQuery( "#field_1_6 .ginput_container" ) );

});