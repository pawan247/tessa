/* javascript*/
var $j = jQuery.noConflict();

/*
* page Preloader
*/


$j(window).load(function(){
	/*
	setTimeout(function(){ 
        $j('.page_loader').fadeOut(500);
        $j('body').css({"overflow":"auto"});
	}, 1000);
	*/

    $j('.page_loader').fadeOut(500);
    // $j('body').css({"overflow":"auto"});

	/*
	* inner page submenu 
	*/

	
	if ($j(".triangle_box_position").length > 0) {
		console.log('adfad');
		var page_content_offset = $j('.page_content_wrapper').offset();
		var triangle_box = $j('.triangle_box .triangle_box_position').offset();

		var final = ( page_content_offset.top - triangle_box.top ) * -1;
		console.log(final);
		$j('.submenu_box').css({'top': (final - 19)});
	}
	
});


$j(window).resize(function(){
	if ($j(".triangle_box_position").length > 0) {
		console.log('adfad');
		var page_content_offset = $j('.page_content_wrapper').offset();
		var triangle_box = $j('.triangle_box .triangle_box_position').offset();

		var final = ( page_content_offset.top - triangle_box.top ) * -1;
		console.log(final);
		$j('.submenu_box').css({'top': (final - 19)});
	}
});


jQuery(document).ready(function(){
		/*
		* footer blog slider
		*/
		$j('.blog_slider').slick({
			dots: false,
			arrows: true,
			infinite: true,
			speed: 300,
			autoplay: true,
			autoplaySpeed: 10000,
			slidesToShow: 1,
			slidesToScroll: 1,
			draggable: false,
			prevArrow: '.blog_slider_next'
		});

		/*
		* blog detail page featured image slider
		*/
		$j('.featured_slider').slick({
			adaptiveHeight: true,
			dots: false,
			arrows: true,
			infinite: true,
			speed: 300,
			autoplay: true,
			slidesToShow: 1,
			slidesToScroll: 1,
			draggable: true,
			prevArrow: '.feat_previous', 
			nextArrow: '.feat_next'			
		});

		/*
		* blog list page category slider
		*/
		$j('.cat_slider').slick({
			dots: false,
			arrows: true,
			infinite: true,
			speed: 300,
			autoplay: true,			
			slidesToShow: 4,
			slidesToScroll: 1,
			prevArrow: '.cat_previous', 
			nextArrow: '.cat_next', 		  
			responsive: [
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
					infinite: true,
					dots: false
				}
			},
			{
				breakpoint: 769,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
					infinite: true,
					dots: false		        
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1,
					infinite: true,
					dots: false		        
				}
			}
			]
		});


		/*
		* 
		*/
		$j('.feature_click').click(function(){
			$j(this).parents('.feature_content').addClass('feature_content_hide');
			$j(this).parents('.hexabox_wrap').find('.feature_click_wrap').addClass('feature_show');
		});

		/*
		* header menu
		*/
		/*$j('.menu_icon').click(function(){
			$j('.navigation_wrap').toggle();
		});*/

		/*
		* inner page submenu 
		*/
		$j(document).ready(function(){
			$j('.submenu_wrap').removeClass('submenu_minus');
			$j('.submenu_wrap').addClass('submenu_plus');
			$j('body').addClass('submenu_box_hide');
			$j('.submenu_wrap').click(function(event){
				if ($j(this).hasClass('submenu_plus')){
					$j(this).removeClass('submenu_plus');
					$j(this).addClass('submenu_minus');
				} else if($j(this).hasClass('submenu_minus')){
					$j(this).removeClass('submenu_minus');
					$j(this).addClass('submenu_plus');
				}
				$j('body').toggleClass('submenu_box_hide');
				event.stopPropagation();
			});
		})
		$j(window).on("load resize", function (){

	    	var body_width = $j('body').width();
	      	if(body_width > 1920){
  				$j('.submenu_wrap').removeClass('submenu_plus');
				$j('.submenu_wrap').addClass('submenu_minus');
				$j('body').removeClass('submenu_box_hide');
			}else{
				$j('.submenu_wrap').removeClass('submenu_minus');
				$j('.submenu_wrap').addClass('submenu_plus');
				$j('body').addClass('submenu_box_hide');
			}
		}).resize();

		/*$j('.submenu_box').click(function(event1){
			event1.stopPropagation();
		});*/

		/*$j('body').click(function(){
			if($j('.submenu_wrap').hasClass('submenu_minus')){
				$j('.submenu_wrap').removeClass('submenu_minus');
				$j('.submenu_wrap').addClass('submenu_plus');
			}
			$j('.submenu_box').addClass('submenu_box_hide');
		});*/
		/*
		* inner page why tech popup
		*/
	 	$j('.tech_box span').click(function(){
			$j('.why_tech_wrap').show();
		});

		$j('.tech_col_right').click(function(){
			$j('.why_tech_wrap').hide();
		});

		function about_tech_triangle(){
			var tech_width = $j('.tech_col_left').outerWidth(true);
			var tech_height = $j('.tech_col_left').outerHeight(true);

			$j('.left_triangle').css({
				'border-left-width':tech_width,
				'border-top-width': tech_height,
				'border-bottom-width': tech_height
				});
		}

		$j('.tech_box span').click(function(){
			setTimeout(function(){ about_tech_triangle(); },100);
			about_tech_triangle()
		});

		$j('.tech_box span').click(function(){
			$j(window).resize(function(){
				about_tech_triangle()
			});
		});


		/*
		* who we are page (team member)
 		*/

		$j('.lead-info-overlay > a').click(function() {
			$j('.leadership-group').find('.collapse').removeClass('in');
			$j('.leader-tile').removeClass('active');
			$j(this).parents('.leader-tile').addClass('active');
		});

		$j('.lead-info-overlay > a').click(function() {
			var clickID=$j(this).attr('customclass');

			if($j('#'+clickID).hasClass('leadershipOpen')){
				//alert('TRUE');
				$j('#'+clickID).removeClass('leadershipOpen');
				$j(this).parents('.leader-tile').removeClass('active');
			} else {
				$j('.leadership-group').find('.leadershipOpen').removeClass('leadershipOpen');
				$j('.leader-tile').removeClass('active');
				$j('#'+clickID).addClass('leadershipOpen', 1000, "ease" );
				$j(this).parents('.leader-tile').addClass('active');
			}
		 });


		/*
		* home page book effect slider
		*/

		/*
		$('.book_right').click(function(){
			$($('.specialty_slider_wrap .specialty_slide').get().reverse()).each(function() {
				if(!$(this).hasClass('to_right')){
					$(this).removeClass('to_left');
					$(this).addClass('to_right');
					return false; 
				}
			});
		});

		$('.book_left').click(function(){
			$($('.specialty_slider_wrap .specialty_slide').get().reverse()).each(function() {
				if(!$(this).hasClass('to_left')){
					$(this).removeClass('to_right');
					$(this).addClass('to_left');
					return false; 
				}
			});
		});

		*/

	
		var a = 89;
		$j('.specialty_slider_wrap .specialty_slide').each(function() {
			$j(this).css('z-index', a);
			a++;
		});

		
		$j('.book_left').click(function(){
			// $j('.slider_click_outer').hide();
			$j('.specialty_slider_wrap .specialty_slide').each(function(){
					
				if($j(this).hasClass('slide_index')){

					$j(this).removeClass('to_right');
					$j(this).addClass('to_left');

					$j(this).removeClass('slide_index');
					$j(this).next().addClass('slide_index');

					$j(this).removeClass('z_index_99');
					$j(this).next().addClass('z_index_99');
				
					$j(this).children().each(function(){
						if($j(this).hasClass('child_show')){
							$j(this).removeClass('child_show');
							$j(this).addClass('child_hide');
						} else if($j(this).hasClass('child_hide')){
							$j(this).removeClass('child_hide');
							$j(this).addClass('child_show');
						}
					});
					return false; 
				}
			});
		});

		$j('.book_right').click(function(){
			// $j('.slider_click_outer').hide();
			$j('.specialty_slider_wrap .specialty_slide').each(function(){
				
				if($j(this).hasClass('slide_index')){

					$j(this).prev().removeClass('to_left');
					$j(this).prev().addClass('to_right');

					$j(this).removeClass('slide_index');
					$j(this).prev().addClass('slide_index');

					$j(this).removeClass('z_index_99');
					$j(this).prev().addClass('z_index_99');


					$j(this).prev().children().each(function(){

						if($j(this).hasClass('child_hide')){
							$j(this).removeClass('child_hide');
							$j(this).addClass('child_show');
						} else if($j(this).prev().hasClass('child_show')){
							$j(this).removeClass('child_show');
							$j(this).addClass('child_hide');
						}
					});
					return false; 
				}		
			});
		});

	
		$j('.book_click_button').hover(function(){
			$j('.slider_click_outer').toggle();

			$j('.specialty_slider_wrap .specialty_slide').each(function(){
				if($j(this).hasClass('slide_index')){

					var firstText = $j(this).prev().find('.slide_child').last().text();
					var secondText = $j(this).find('.slide_child').first().text();
					// console.log(firstText);
					// console.log(secondText);
					$j('.slider_click_text h2').text(firstText + " + " +secondText);

					var current_index = $j(this).index();
					//console.log(current_index);

					var paragrapText = $j('.click_text_wrap .click_text').eq(current_index - 1).text();
					//console.log(paragrapText);
					$j('.slider_click_text p').text(paragrapText);



					return false; 
				}
			});
		});


/*
		$j('.book_left').click(function(){
	
			$j('.specialty_slider_wrap .specialty_slide').each(function(){

				if($j(this).hasClass('slide_index')){

					$j(this).removeClass('to_right');
					$j(this).addClass('to_left');

					$j(this).removeClass('slide_index');
					$j(this).next().addClass('slide_index');

					$j(this).removeClass('z_index_99');
					$j(this).next().addClass('z_index_99');
					return false; 
				}
			});
		});

		$j('.book_right').click(function(){

			$j('.specialty_slider_wrap .specialty_slide').each(function(){
				
				if($j(this).hasClass('slide_index')){

					
					$j(this).prev().removeClass('to_left');
					$j(this).prev().addClass('to_right');

					$j(this).removeClass('slide_index');
					$j(this).prev().addClass('slide_index');

					$j(this).removeClass('z_index_99');
					$j(this).prev().addClass('z_index_99');

					return false; 
				}
			
			});
		});
*/

/*
		$j('.book_left').click(function(){
			
			$j('.specialty_slider_wrap .specialty_slide').each(function(){

				if($j(this).hasClass('slide_index')){

					$j(this).removeClass('to_right');
					$j(this).addClass('to_left');

					$j(this).removeClass('slide_index');
					$j(this).next().addClass('slide_index');

					$j(this).removeClass('z_index_99');
					$j(this).next().addClass('z_index_99');


					// $j(this).removeClass('to_right').addClass('to_left').delay(500).queue(function(){
					// 	$j(this).removeClass('slide_index').next().addClass('slide_index');
					//     $j(this).removeClass('z_index_99').next().addClass('z_index_99');
					// });

					return false; 
				}
			});
		});

		$j('.book_right').click(function(){

			$j('.specialty_slider_wrap .specialty_slide').each(function(){
				
				if($j(this).hasClass('slide_index')){
					
					$j(this).prev().removeClass('to_left');
					$j(this).prev().addClass('to_right');

					$j(this).removeClass('slide_index');
					$j(this).prev().addClass('slide_index');

					$j(this).removeClass('z_index_99');
					$j(this).prev().addClass('z_index_99');
				
					return false; 
				}
			
			});
		});
*/


		function arrow_right_hide_show(){
			if($j('.specialty_slider_wrap .specialty_slide.slide_index').index() == 1){
				$j('.book_right').hide();
			} else {
				$j('.book_right').show();
			}
			var slide_count = $j('.specialty_slider_wrap .specialty_slide').length;
			if($j('.specialty_slider_wrap .specialty_slide.slide_index').index() == slide_count - 1){
				$j('.book_left').hide();
			} else {
				$j('.book_left').show();
			}		
		}

		arrow_right_hide_show();

		$j('.specialty_section .fa').click(function(){
			arrow_right_hide_show();
		});

		/*
		* SEO page popup
		*/
	 	$j('.get_free_consultation_form').click(function(){
			$j('.newsletter_form_wrap').show();
		});

		$j('.newsletter_close').click(function(){
			$j('.newsletter_form_wrap').hide();
		});
});

