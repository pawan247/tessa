<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/css/media_style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/slick/slick.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/slick/slick-theme.css"/>

	<link href="https://fonts.googleapis.com/css?family=Cairo:200,300,400,600,700,900" rel="stylesheet"> 
	
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="page_loader">
	<div class="img_wrapper">
		<img src="<?php echo get_stylesheet_directory_uri()?>/images/loader_icon.png" alt="Loading..." class="loader_icon0" />
		<!-- <p class="loading_text">Loading..</p> -->
	</div>
</div>

<section class="newsletter_form_wrap">
	<div class="newsletter_row">
		<div class="newsletter_intro">
			<div class="newsletter_intro_neutral">
				<div class="newsletter_close">
					<i class="fa fa-close" title="Cancle"></i>
				</div>
				<div class="newsletter_text">
					<span>Reach out to our experts</span>
					<p>Need help improving your online presence? Our team of experienced digital marketing pros are ready to help.  Fill out the form and we can get started.</p>
				</div>
			</div>
		</div>
		<div class="newsletter_form_outer">
			<div class="newsletter_form_neutral">
				<div class="newsletter_form_box">
						<div class="newsletter_outer">
					<?php if(is_page( '2910' )) { ?>
							<?php echo do_shortcode('[gravityform id=5 title=false description=false ajax=true]'); ?>
					<?php } else { 
						echo do_shortcode('[gravityform id=1 title=false description=false ajax=true]'); }
						?>
						</div>
					
				</div>
			</div>
		</div>
	</div>
</section>

<header>
	<section class="header_wrap seo_header">
		<div class="logo_wrap">
			<?php if ( get_theme_mod( 'tech_logo' ) ) : ?>
                <div class='site-logo'>
                    <a href='<?php echo esc_url( home_url( '/' ) ); ?>' title='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>' rel='home'><img src='<?php echo esc_url( get_theme_mod( 'tech_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>'></a>
                </div>
            <?php else : ?>
                <hgroup>
                    <h1 class='site-title'>
                    	<a href='<?php echo esc_url( home_url( '/' ) ); ?>' title='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>' rel='home'><?php bloginfo( 'name' ); ?></a>
                    </h1>
                    <h2 class='site-description'><?php bloginfo( 'description' ); ?></h2>
                </hgroup>
            <?php endif; ?>
		</div>
		
		<div class="menu_wrap">
			<div class="phone_box">
				<img src="<?php echo get_stylesheet_directory_uri()?>/images/seo/header_phone.png" alt="" />
				<div class="phone_text">
				<?php $phn = get_option('my_phone'); 
						$phn_arr = explode('.', $phn);
						$tel = implode('', $phn_arr);
				?>
					<a href="tel:<?php echo $tel; ?>"><?php echo get_option('my_phone') ?></a>
				</div>
			</div>
		</div>
	</section>
</header>


