<?php
/**
 * The template for displaying all awards 
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<main>
	<section class="page_banner">
			<div class="header_img" style="background-image: url('https://tech.tech/wp-content/uploads/2017/10/Case-Study-Header.jpg');"></div>
			<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Awards</h2>
				</div>
			</div>
		</div>	
	</section>

	<section class="page_content_wrapper">
	    <div class="triangle_box">
	        <div class="triangle_box_position"></div>
	        <!-- to get offset posiion of triangle box -->
	        <div class="tech_box">
	            <span>Why tech?</span>
	        </div>
	        <div class="hexagon_title_box">
	            <div class="industry_hexagon" style="background-image: url('https://tech.tech/wp-content/themes/techchild/images/home/feature_1.jpg');">
	                <div class="industry_color_overlay" style="background-color: rgba(0, 137, 207, 0.8);"></div>
	                <div class="industry_text">Brand Development &amp; Protection</div>
	            </div>
	        </div>
	    </div>
	    <div class="page_content">
	        <div class="container">
	        	
					<?php while(have_posts()):the_post();
								$headerImageUrl = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'full' );
								 ?>
	            <div class="row">
	                <div class="col-xs-12 col-sm-12 col-md-12">
	                    <h1 class="section_head margin_bottom_20"><?php the_title(); ?></h1>
	                   
	                </div>
	                <div class="col-xs-12 col-sm-12 col-md-8">
	                    <h2 class="section_sub_head margin_bottom_20"> <?php
														$category = get_the_terms( $post->ID, 'testimonials-category' );     
															foreach ( $category as $cat){
															   echo "Category -: ".$cat->name;
															} //echo $category_detail; ?></h2>
						<h2 class="section_sub_head margin_bottom_20"><?php echo 'Client Name -: ' ?><?php the_field('client_name'); ?> </h2>
	                </div>
	                <div class="col-xs-12 col-sm-12 col-md-8">
	                    <div class="page_vc_content">
	                        <?php the_content(); ?>
	                    </div>
	                     <div class="websiteLink"><a href="<?php the_field('website_link_for_awards'); ?>" target="_blank" class="btn btn-info">Website Link</a></div>
	                </div>
	                <div class="col-xs-12 col-sm-12 col-md-4">
	                    <img src="<?php echo $headerImageUrl; ?>" alt="" width="100%">
	                </div>

	            </div>
	        <?php endwhile; ?>
	        </div>
	    </div>
	</section>

</main>

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
