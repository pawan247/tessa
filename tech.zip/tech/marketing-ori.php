<?php 
/*
Template Name: Marketing Template
*/
?>
<?php get_header(); ?>
<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Marketing</h2>
				</div>
			</div>
		</div>	
	</section>
		
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-6">
						<h1 class="section_head"><?php the_title(); ?></h1>
						<div class="page_vc_content margin_bottom_40">
							<?php 
								while ( have_posts() ) : the_post(); 
				            		the_content(); 
				        		endwhile ;
							?>
						</div>
						<div class="tech_logo">
							<?php

									// check if the repeater field has rows of data
									if( have_rows('technology_award_logo') ): ?>
							<ul>
								<?php while ( have_rows('technology_award_logo') ) : the_row(); ?>
								<li>
									<a href="<?php  the_sub_field('case_study_link'); ?>"><img src="<?php  the_sub_field('image'); ?>" alt="" /></a>
								</li>
							<?php endwhile; endif; ?>
							<!-- 	<li>
									<img src="https://tech.tech/wp-content/uploads/2017/09/Gettysburg-museum-history-1.jpg" alt="" />
								</li>								
								<li>
									<img src="https://tech.tech/wp-content/uploads/2017/09/Dominion-Legal-Logo-2.jpg" alt="" />
								</li>
								<li>
									<img src="https://tech.tech/wp-content/uploads/2017/09/altland-house.jpg" alt="" />
								</li> -->
								
							</ul>
						</div>					
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6 text-center">
						<div class="industry_col">
							<?php 
							$categories = get_terms(
							array('marketing-category'),
							array(
									'orderby'       => 'term_order',
							        'hide_empty'    => false,
							    )
							);
							
							//print_r($categories); ?>
							<div class="industry_row">
								<?php $row = 1;
									$count =  1;
								foreach ($categories as $key => $value) { 
									$row%2!=0 ? $check=3 : $check=2; 
									$term_link = get_term_link($value->term_id , 'marketing-category' );
									if($count == $check){ 
										 ?>
										
											<div class="industry_hexagon_wrap">
												<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
													<div class="industry_color_overlay"></div>
													<a href="<?php echo $term_link; ?>" class="industry_text"><?php echo $value->name; ?></a>
												</div>
											</div>
										
										<?php 
											$count = 1; 
											$row++; 
										?>
									</div><div class="industry_row">
									<?php  } else { ?>
											<div class="industry_hexagon_wrap">
													<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
														<div class="industry_color_overlay"></div>

														<a href="<?php echo $term_link; ?>" class="industry_text"><?php echo $value->name; ?></a>
													</div>
											</div>
									
									<?php $count += 1; }
								} ?>
							</div>
						</div>
					</div>	
				</div>
			</div>
		</div>
	</section>	
	<!-- <div style="height: 500px;width: 100%;background-color: #ddd;"></div> -->
</main> 

<?php get_footer(); ?>