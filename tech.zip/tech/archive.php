<?php 
/*
Template Name: Blog Template
*/
?>
<?php get_header(); ?>

<main>

	<?php if( get_field('banner_image',12) ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image',12); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<?php the_archive_title( '<h1>', '</h1>' ); ?>
				</div>
			</div>
		</div>	
	</section>
		
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">

					<div class="col-xs-12 col-sm-8 col-md-9" id="blog_list">
						<div class="row">
							<div class="col-xs-12 col-sm-12 col-md-12">
								<?php
									the_archive_title( '<h2 class="section_head">', '</h2>' );
									the_archive_description( '<div class="taxonomy-description">', '</div>' );
								?>
							</div>
						</div>
						<div class="row blogs_content">
							<div class="col-xs-12 col-sm-12 col-md-12">
								<?php if ( have_posts() ) : ?>
									<div class="blog_list_wrapper">
										<?php while ( have_posts() ) : the_post(); ?>
											<div class="blog_list_outer">
												<h2 class="blog_head"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
												<div class="blog_text_wrap">
													<?php if(has_post_thumbnail()) : ?>	
														<div class="blog_feature_img" style="background-image: url('<?php echo get_the_post_thumbnail_url(); ?>');"></div>
													<?php else: ?>
														<div class="blog_feature_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');"></div>
													<?php endif ; ?>
													<div class="blog_text">
														<p class="margin_bottom_0 blog_date_time"><?php the_time('F jS, Y') ?></p>
														<p><?php $desc = get_the_content();
													 		echo substr(strip_tags($desc),0,200).'...';
															 ?><a href="<?php the_permalink(); ?>">&nbsp; Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
													</div>
												</div>
											</div>
										<?php endwhile; ?>
										<?php wp_reset_postdata(); ?>
									</div>
								<?php endif; ?>
								<nav class="prev-next-posts">
							      <?php echo get_next_posts_link( 'Older Entries',$result->max_num_pages); // display older posts link ?>
							      <?php echo get_previous_posts_link( 'Newer Entries' ); // display newer posts link ?>
								</nav>
								<?php $count = $GLOBALS['wp_query']->post_count; 
									if($count==5 || $count > 5):
								?>
									<div class="see_list_wrap">
										<a id="see_list" href="#blog_list" title="To Top"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-3">
						 <?php get_sidebar('blogs'); ?>
					</div>	
				</div>
			</div>
		</div>
		
	</section>	

</main> 

<?php get_footer(); ?>