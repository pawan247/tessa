<?php

/**

 * The template for the sidebar containing the main widget area

 *

 * @package WordPress

 * @subpackage Twenty_Sixteen

 * @since Twenty Sixteen 1.0

 */

?>

<div class="blog_sidebar_wrapper">

			<aside class="sidebar_wrap">

				<!-- <h2 class="sidebar_wrap_head">Search</h2> -->

				<?php get_search_form(); ?>

				<!-- <form action="" method="" class="search_form">

					<input type="text" value="" class="seacrh_field">

					<button type="button" value="" class="search_submit"><i class="fa fa-search"></i></button>

				</form> -->

			</aside>

			<aside class="sidebar_wrap">

				<h2 class="sidebar_wrap_head">Popular Post</h2>

				<ul class="popular_post_wrap">

					<?php // Display blog posts on any page @ https://m0n.co/l

					$args = array(
					'post_type'=> 'post',
					'post_status' => 'publish',
					'posts_per_page' => 3 // this will retrive all the post that is published 
					);
					$result = new WP_Query( $args );
					if ( $result-> have_posts() ) : ?>
					<?php while ( $result->have_posts() ) : $result->the_post(); ?>
					<li>

						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

						<p><?php $desc = get_the_content();

						echo substr(strip_tags($desc),0,100).'...';

						?><a href="<?php the_permalink(); ?>">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>

					</li>

					<?php endwhile; ?>
				<?php endif; ?>
				<?php wp_reset_postdata(); ?>
				</ul>

			</aside>

			<aside class="sidebar_wrap">

				<h2 class="sidebar_wrap_head">Archives</h2>

				<ul class="archives_wrap">

					<?php $args = array(

						'type'            => 'yearly',

						'limit'           => '',

						'format'          => 'html', 

						'before'          => '',

						'after'           => '',

						'show_post_count' => false,

						'echo'            => 1,

						'order'           => 'DESC',

					    'post_type'     => 'post'

					);

					wp_get_archives( $args ); ?>

				</ul>

			</aside>

			<aside class="sidebar_wrap">

				<h2 class="sidebar_wrap_head">Tag Cloud</h2>

				<?php $tags = wp_tag_cloud( 'smallest=10&format=array&largest=10'); //print_r($tags); ?>

				<ul class="tag_cloud_wrap">

					<?php foreach($tags as $tag): ?>

					<li>

						<?php echo $tag; ?>

					</li>

					<?php endforeach; ?>									

				</ul>

			</aside>	

		</div>