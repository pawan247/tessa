	<?php
/*
Template Name: Testimonial Pagee
*/

get_header(); ?>
<?php get_header(); ?>
<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Testimonials</h2>
				</div>
			</div>
		</div>	
	</section>
		
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="margin_bottom_40">
					<?php
					$args = array (
			         'post_type' => 'client_testimonial',
			         'posts_per_page' => '-1',            
			         'order'     => DESC, 
			         'post_status' => 'publish'
			         );
					$testimonial_post = new WP_Query( $args );  
					$count_post = wp_count_posts('client_testimonial');	
					$published_posts = $count_post->publish;				
				  	$i=1;
				  	while ( $testimonial_post->have_posts() ): $testimonial_post->the_post();
			    	?>
			    		<div class="share-experience" id="testimoid-<?php echo $i ?>">
			    			<i class="fa fa-heart"></i>
			    			<?php the_content();?>
			    			<p><?php
					    	 the_title();	
					    	 ?></p>
			    		</div> 
					<?php
			    	$i++;		
					endwhile;
					?>
				</div>
			</div>
		</div>
	</section>	
	<!-- <div style="height: 500px;width: 100%;background-color: #ddd;"></div> -->
</main> 

		
<?php get_footer(); ?>