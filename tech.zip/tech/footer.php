<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<footer class="footer_wrap <?php if(! is_front_page()){ echo "inner_page_footer" ; } ?>" >
	<div class="footer_img" style="background-image: url('/wp-content/uploads/2018/06/seo-specialist.jpg');"></div>
	<section class="footer_main">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 text-center footer_logo_col">
					<img src="/wp-content/uploads/2018/06/seo-optimization-company.png" title="Web Marketing Company" alt="Internet Marketing SEO" width="202" height="61" />
				</div>
				<!-- Left -->
				<div class="col-xs-12 col-sm-6 col-md-6 footer_left">
					<div class="contact_tech_col">
						<span>Work with us?</span><a href="<?php echo get_permalink('76'); ?>" class="contact_tech_button">Contact tech</a>
					</div>
				
					<div class="tech_link">
					<!-- <ul> -->
						<?php 
					 	 	if (function_exists('wp_nav_menu')) {
					  		wp_nav_menu(array('theme_location'=>'footer-main-menu'));
		          			}
						?>
					<!-- </ul> -->
					</div>

					<div class="social_link">
						<ul>
							<li>
								<a target="_blank" href="<?php echo get_option('fb_url'); ?>">
									<!-- <img src="<?php echo get_stylesheet_directory_uri().'/images/social_icon/facebook.png' ?>"> -->
									<span style="background-image: url(<?php echo get_stylesheet_directory_uri().'/images/social_icon/facebook_hover.png' ?>);"></span>
								</a>
							</li>
							<li>
								<a target="_blank" href="<?php echo get_option('twitter_url'); ?>">
									<span style="background-image: url(<?php echo get_stylesheet_directory_uri().'/images/social_icon/twitter_hover.png' ?>);"></span>
								</a>
							</li>
							<li>
								<a target="_blank" href="<?php echo get_option('linkedin_url'); ?>">
									<span style="background-image: url(<?php echo get_stylesheet_directory_uri().'/images/social_icon/linked_in_hover.png' ?>);"></span>
									<!-- <img src="<?php echo get_stylesheet_directory_uri().'/images/social_icon/linked_in.png' ?>"> -->
								</a>
							</li>
							<li>
								<a target="_blank" href="<?php echo get_option('youtube_url'); ?>">
									<span style="background-image: url(<?php echo get_stylesheet_directory_uri().'/images/social_icon/you_tube_hover.png' ?>);"></span>
									<!-- <img src="<?php echo get_stylesheet_directory_uri().'/images/social_icon/you_tube.png' ?>"> -->
								</a>
							</li>
							<li>
								<a target="_blank" href="<?php echo get_option('googleplus_url'); ?>">
									<span style="background-image: url(<?php echo get_stylesheet_directory_uri().'/images/social_icon/google_plus_hover.png' ?>);"></span>
									<!-- <img src="<?php echo get_stylesheet_directory_uri().'/images/social_icon/google_plus.png' ?>"> -->
								</a>
							</li>
							<li>
								<a target="_blank" href="<?php echo get_option('instagram_url'); ?>">
									<span style="background-image: url(<?php echo get_stylesheet_directory_uri().'/images/social_icon/instagram_hover.png' ?>);"></span>
									<!-- <img src="<?php echo get_stylesheet_directory_uri().'/images/social_icon/instagram.png' ?>"> -->
								</a>
							</li>
						</ul>
					</div>
				</div>

				<?php 
					$args = array(
							'posts_per_page' => 3
						);
					$blog_query = new WP_Query($args);
				?>
				<div class="col-xs-12 col-sm-6 col-md-6 footer_right">
					<?php if( $blog_query->have_posts() ): ?>
					<div class="blog_slider">
						<?php while( $blog_query->have_posts() ) : $blog_query->the_post();  ?>
							<div class="blog_slide">
								<h2><?php echo get_the_title(); ?></h2>
								<div class="blog_wrapper">
								<?php $featured_img = get_the_post_thumbnail_url($post->ID,'full'); ?>
									<?php if($featured_img){ ?>
									<img src="<?php echo $featured_img; ?>" alt="" />
									<?php } else { ?>
									<img src="<?php echo get_stylesheet_directory_uri().'/images/home/blog_img.jpg'; ?>" alt="" />
									<?php } ?>
									<div class="">
										<p><?php $desc = get_the_content();
										 echo substr(strip_tags($desc),0,200).'...';
										 ?></p>
										<a href="<?php the_permalink(); ?>">Read More</a><span class="blog_slider_next">Next <i class="fa fa-angle-right" aria-hidden="true"></i></span>
									</div>
								</div>
							</div>
						<?php endwhile; endif; ?>
						<?php wp_reset_query();	 // Restore global post data stomped by the_post(). ?>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12 text-center">
					<div class="footer_awards blog_slide">
						<h2>Award Winning Website Design, SEO & PPC Management</h2>
						<ul>
							<li>
								<a href="<?php echo get_option('award_winnig_url_1'); ?>">
									<img src="/wp-content/uploads/2018/06/tysons-corner-seo.png" title="SEO Consultant" alt="SEO Marketing" height="170" width="150" />
								</a>
							</li>
							<li>
								<a href="<?php echo get_option('award_winnig_url_2'); ?>">
									<img src="/wp-content/uploads/2018/06/seo-service.png" title="Website Marketing" alt="SEO Company Near Me" height="54" width="150" />
								</a>
							</li>
							<li>
								<a href="<?php echo get_option('award_winnig_url_3'); ?>">
									<img src="/wp-content/uploads/2018/06/seo-internet-marketing.png" title="Marketing SEO" alt="Online Marketing Company" height="170" width="150" />
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12 text-center">
					<p class="footer_text"><?php echo get_option('my_address'); ?></p>
				</div>

				<!-- <div class="" style="height: 300px;width:300px;"></div> -->
			</div>		
		</div>
	</section>
</footer>
			

<?php wp_footer(); ?>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri()?>/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri()?>/vendor/slick/slick.min.js"></script>
<script type="text/javascript">
var $j = jQuery.noConflict();

	function isUrlValid(url){
		return /\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i.test(url);
	}

	$j(document).ready(function(){

		if(localStorage.menuon == 'active_menu'){
			$j('nav').removeClass("inactive");
			$j('nav').addClass("active_menu");
		}else if(localStorage.menuon == 'inactive'){
			$j('nav').removeClass("active_menu");
			$j('nav').addClass("inactive");
		}else{
			localStorage.setItem("menuon", "inactive");
		}


		$j('nav').addClass(localStorage.menuon);

		$j('.menu_icon').click(function(){
		if (typeof(Storage) !== "undefined") {
    	// Store
    		if ($j('nav').hasClass("inactive")){
    			$j('nav').removeClass('inactive');
    			$j('nav').addClass('active_menu');
    			localStorage.setItem("menuon", "active_menu");
    		}else{
    			$j('nav').removeClass('active_menu');
    			$j('nav').addClass('inactive');
    			localStorage.setItem("menuon",'inactive');
    		}
    	}
    });

		$j('.newsletter_submit').click(function(){
			var email = $j('#emailId').val();
			if(email){
				if( !isUrlValid( email ) ){
					$j('.validation_text_wrapper').empty();

					$j('.validation_text_wrapper').html('<div class="validation_text" id="failure">Please enter valid Url <br> (www.example.com)</div>');
				}else{
					$j( ".validation_text_wrapper" ).remove();
					$j('#failure').html('');
					$j('#input_1_9').val(email);
					$j('.newsletter_form_wrap').show();
				}
			}
			else{
				$j('.validation_text_wrapper').html('<div class="validation_text" id="failure">Please enter Url</div>');

			}
		});

    	$j("#see_list").click(function() {
	    $j('html, body').animate({
	        scrollTop: $j("#blog_list").offset().top
	    }, 2000);
		});

		$j('.newsletter_close').click(function(){
			location.reload();
		});
		
	});
	
jQuery(".call-action-button a").click(function(){
		jQuery(".tech_box span").trigger("click");
});
</script>
<script type="text/javascript">
function genericSocialShare(url){
    window.open(url,'sharer','toolbar=0,status=0,width=648,height=395');
    return true;
}
</script>
        
</body>
</html>
