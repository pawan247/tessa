<?php
/**
 * The template for displaying search results pages
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
	
	<main>

		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12">
						<?php printf('<h1>' . esc_html( get_search_query() ) . '</h1>' ); ?>
					</div>
				</div>
			</div>	
		</section>
			
		<section class="page_content_wrapper">
			<div class="triangle_box">
				<div class="tech_box">
					<span>Why tech?</span>
				</div>
			</div>
				<div class="page_content">
					<div class="container">
						<div class="row">
							<div class="col-xs-12 col-sm-8 col-md-9 margin_bottom_20" id="blog_list">
								<div class="row">							
									<div class="col-xs-12 col-sm-12 col-md-12">
										<h2 class="section_head">Search Results for: <?php echo esc_html( get_search_query() ); ?> </h2>
									</div>
								</div>

								<?php if ( have_posts() ) : ?>
									<?php while ( have_posts() ) : the_post(); ?>
										<div class="search_blog_outer">
											<?php the_title( sprintf( '<h2 class="blog_head"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );?>
											<?php the_excerpt(); ?>
										</div>
									<?php endwhile; ?>
									<?php wp_reset_postdata(); ?>
									<?php 
										the_posts_pagination( array(
										'prev_text'          => __( 'Previous page', 'twentysixteen' ),
										'next_text'          => __( 'Next page', 'twentysixteen' ),
										'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>',
									) ); ?>
								<?php else : 
									get_template_part( 'template-parts/content', 'none' );
								endif; ?>
							</div>
							<div class="col-xs-12 col-sm-4 col-md-3">
								 <?php get_sidebar('blogs'); ?>
							</div>	
						</div>
					</div>
				</div>
			
		</section>	
	</main> 
<?php //get_sidebar(); ?>
<?php get_footer(); ?>
