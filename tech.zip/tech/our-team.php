<?php 
/*
Template Name: Our Team Template
*/
?>
<?php get_header(); ?>
<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>About Us</h2>
				</div>
			</div>
		</div>	
	</section>
		

<div class="page_outer">
	<div class="submenu_wrap submenu_minus">
		<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
		<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
		<div class="menu-heading">Menu</div>
	</div>
	<?php
	global $post;
	
    //GET CHILD PAGES IF THERE ARE ANY
    $children = get_pages('child_of='.$post->ID);
 
    //GET PARENT PAGE IF THERE IS ONE
    $parent = $post->post_parent;
    //echo $parent ; 
 
    //DO WE HAVE SIBLINGS?
    $siblings =  get_pages('child_of='.$parent);
    //print_r($siblings);
 
    if( count($children) != 0) {
       $args = array(
         'depth' => 1,
         'title_li' => '',
         'child_of' => $post->ID
       );
 
    } elseif($parent != 0) {
        $args = array(
             'depth' => 1,
             'title_li' => '',
             'exclude' => $post->ID,
             'child_of' => $parent
           );
    }
    $parent_id = get_post_ancestors( $post->ID );

    //Show pages if this page has more than one sibling 
    // and if it has children 
    if(count($siblings) > 1 && !is_null($args))   
    { ?>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<ul class="pages-list">
					<li><a href="<?php the_permalink($parent_id[0]); ?>"><?php echo get_the_title($parent_id[0]); ?></a></li>
	         		<?php wp_list_pages($args);  ?>
	         </ul>
			</div>
		</div>
	<?php } ?>	
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12">
						<h1 class="section_head"><?php the_title(); ?></h1>
						<div class="page_vc_content">
							<?php 
							 /*print_r(get_post_ancestors(168)); */
								while ( have_posts() ) : the_post(); 
				            		the_content(); 
				        		endwhile ;
							?>
						</div>
					</div>

					<div class="col-xs-12 col-sm-12 col-md-12">

						    <?php 
						    $lead_title = ''; $description = '';
							$myposts=array(
							'post_type' => 'team',
							'posts_per_page' => -1,
							);
							$loop = new WP_Query( $myposts );
							?>
							<?php $i=0;
							if ( $loop->have_posts() ): ?>
							    <div class="leadership-group">
							        <!--leader-tile-1-->
									  <?php 
									  $html = '';
									  while ( $loop->have_posts() ) : $loop->the_post(); $i++;
				                         // if($i == 2){
				                            //$active_class = 'active';
				                            //$collapse_open = 'leadershipOpen';
				                         // }else{
				                          	//$active_class='';
				                          	//$collapse_open='';
				                          //} 
			                          		$collapse_class = 'collapseExample'.$i;
			                          		
			                          		if(has_post_thumbnail()){
			                          		$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
			                          		}else{
			                          		$featured_img_url = get_stylesheet_directory_uri().'/images/team_avatar.jpg';
			                          		}?>
			                          	
								       		<?php $lead_title .='<div class="leader-tile '.$active_class.'"><div class="lead-img"><div class="lead_box"><img title="" alt="" src="'.$featured_img_url.'" width="100%" class="img-responsive"><div class="lead-info-overlay"><a role="button" customclass="'.$collapse_class.'" href="javascript:void(0)"><div class="team-textcenter"><h2>'.get_the_title().'</h2><h4><strong>'.get_field('designation').'</strong></h4></div></a></div></div></div></div>' ; ?>
								       	 
											<?php $description .='<div id="'.$collapse_class.'" class="leader-hide"><div class="leader-content"><h2>'.get_the_title().'</h2><h4>'.get_field('designation').'</h4><p class="margin_bottom_20">'.get_the_content().'</p><ul class="blog_social_list margin_bottom_0"><li><a href="mailto:'.get_field('gmail',get_the_ID()).'" target="_blank"><img src="https://tech.tech/wp-content/themes/techchild/images/social_icon/mail_black.png" width="25"></a></li><li><a href="'.get_field('linkedin',get_the_ID()).'" target="_blank"><img src="https://tech.tech/wp-content/themes/techchild/images/social_icon/linked_in_black.png" width="25"></a></li><li><span>Connect with '.get_the_title().'</span></li></ul></div></div>'; ?>
										
											<?php if($i%3 == 0 ):

												$html .= $lead_title.$description.'</div><div class="leadership-group">';
												$lead_title = ''; $description = '';
											endif; ?>
										<?php endwhile;
										if (!empty($lead_title) && !empty($description)) {
											$html .= $lead_title.$description.'</div><div class="leadership-group">';
										}
										echo $html;
										?>
								</div>
							<?php endif ; ?>
							<?php wp_reset_postdata();  ?>
					
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
</main> 

<?php get_footer(); ?>