<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/css/media_style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/slick/slick.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri()?>/vendor/slick/slick-theme.css"/>

	<link href="https://fonts.googleapis.com/css?family=Cairo:200,300,400,600,700,900" rel="stylesheet"> 
	
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="page_loader">
	<div class="img_wrapper">
		<img src="/wp-content/uploads/2018/06/seo-marketing-service.png" width="100" height="94" title="Marketing Technology Companies" alt="SEO Web Marketing" class="loader_icon0" />
		<p class="loading_text">Multi-Surface Marketing + Technology.</p> 
		<!-- <p class="loading_text">Our team is comprised of seasoned professionals with deep experience and expertise in all facets of technology and marketing</p> --> 
	</div>
</div>

<!-- <div id="page" class="site">
	<div class="site-inner"> -->
		<section class="why_tech_wrap">
			<div class="tech_row">
				<div class="tech_col_left">
					<div class="left_triangle"></div>
					<div class="left_triangle_text">
						<span class="tech_head">Why tech?</span>
						<h4 class="tech_subhead"></h4>
						<p class="tech_text margin_bottom_20">tech’s formula for your success involves adding deep experience with complex challenges to unparalleled persistence. It’s the intersection of smart marketing + high technology. The result? You meet or exceed your goals, and have the numbers to prove it.</p>
						<?php   
						    $phn = get_option('my_phone'); 
							$phn_arr = explode('.', $phn);
							$tel = implode('', $phn_arr);
						?>
						<p class="tech_text margin_bottom_30">Contact tech <a href="tel:<?php echo $tel; ?>"><?php echo get_option('my_phone') ?></a></p>

						<a href="<?php the_permalink(76); ?>" class="contact_tech_button">Contact tech</a>
					</div>
					
				</div>
				<div class="tech_col_right">
					<div class="right_triangle">
						<img src="<?php echo get_stylesheet_directory_uri()?>/images/seo-expert.png" alt="Internet Marketing Experts" />
					</div>
				</div>
			</div>
		</section>

		<section class="newsletter_form_wrap">
			<div class="newsletter_row">
				<div class="newsletter_intro">
					<div class="newsletter_intro_neutral">
						<div class="newsletter_close">
							<i class="fa fa-close" title="Cancle"></i>
						</div>
						<div class="newsletter_text">
							<span>Reach out to our experts</span>
							<p>Need help improving your online presence? Our team of experienced digital marketing pros are ready to help.  Fill out the form and we can get started.</p>
						</div>
					</div>
				</div>
				<div class="newsletter_form_outer">
					<div class="newsletter_form_neutral">
						<div class="newsletter_form_box">
							<div class="newsletter_outer">									
								<?php 
								if(is_front_page()):
								echo do_shortcode('[gravityform id=1 title=false description=false ajax=true]');
								endif;
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<header>
			<section class="header_wrap">
				<div class="logo_wrap">
						<?php if ( get_theme_mod( 'tech_logo' ) ) : ?>
		                    <div class='site-logo'>
		                        <a href='<?php echo esc_url( home_url( '/' ) ); ?>' title='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>' rel='home'><img src='<?php echo esc_url( get_theme_mod( 'tech_logo' ) ); ?>' title="Technology Marketing" alt="Local SEO Service" width="300" height="290"></a>
		                    </div>
		                  <?php else : ?>
		                    <hgroup>
		                        <h1 class='site-title'><a href='<?php echo esc_url( home_url( '/' ) ); ?>' title='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>' rel='home'><?php bloginfo( 'name' ); ?></a></h1>
		                        <h2 class='site-description'><?php bloginfo( 'description' ); ?></h2>
		                    </hgroup>
		                  <?php endif; ?>
				</div>
				
				<div class="menu_wrap">
					<div class="menu_box text-right">
						<img src="/wp-content/uploads/2018/06/seo-agencies.png" alt="Online Marketing Agency" class="menu_icon" />
						<?php if ( has_nav_menu( 'primary' ) ) : ?>
		                      <nav class="inactive">
		                        <?php
		                          wp_nav_menu( array(
		                            'theme_location' => 'primary',
		                            'menu_class'     => 'primary-menu',
		                           ) );
		                        ?>
		                      </nav><!-- .main-navigation -->
                    	<?php endif; ?>
						<!-- <nav class="navigation_wrap">
							<ul>
								<li class="menu_active"><a href="#">Home</a></li>
								<li><a href="case_studies.php">Case Studies</a></li>
								<li><a href="#">Technology</a></li>
								<li><a href="#">Marketing</a></li>
								<li><a href="#">Blog</a></li>
								<li><a href="#">About</a></li>
							</ul>
						</nav> -->
					</div>
					<div class="phone_box">
						<img src="<?php echo get_stylesheet_directory_uri()?>/images/home/website-optimization.png" alt="Search Engine Optimization Companies" />
						<div class="phone_text">
							<?php /*$phn = get_option('my_phone'); 
								$phn_arr = explode('.', $phn);
								$tel = implode('', $phn_arr);*/
							 ?>
							<a href="tel:<?php echo $tel; ?>"><?php echo get_option('my_phone') ?></a>
						</div>
					</div>
				</div>

			</section>

			<!-- <section class="header_main">
				<nav id="header-nav" class="navbar navbar-default">
					<div class="container">
				    	<div class="navbar-header">
				      		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					       	 	<span class="sr-only">Toggle navigation</span>
					        	<span class="icon-bar"></span>
						        <span class="icon-bar"></span>
						        <span class="icon-bar"></span>
					        </button>
					        <a class="navbar-brand" href="#"><img src="images/logo.png" class="site_logo" alt="" /></a>
					   	</div>
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					      	<ul id="header-nav-ul" class="nav navbar-nav navbar-right header_nav_ul">
								<li><a href="#"><i class="fa fa-user"></i> Home</a></li>
								<li><a href="#">About us</a></li>
								<li><a href="#">services</a></li>
								<li><a href="#">our people</a></li>
								<li><a href="#">process</a></li>
								<li><a href="#">Contact us</a></li>						
					      	</ul>
					    </div>
					</div>
				</nav>
			</section> -->
		</header>

		<!-- <div id="content" class="site-content"> -->
