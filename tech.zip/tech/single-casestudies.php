<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<main>

	<?php if( get_field('banner_image',6) ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image',6); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Case Studies</h2>
				</div>
			</div>
		</div>	
	</section>
		

	<div class="page_outer">
		<div class="submenu_wrap submenu_minus">
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
			<div class="menu-heading">Menu</div>
		</div>
		<?php 
			$categories = get_terms(
						array('casestudies-cat'),
						array(
						        'hide_empty'    => false,
						        'orderby'       => 'title',
						        'order'         => 'ASC'
						    )
						);
				//print_r($categories);

		?>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<ul>
					<?php foreach ($categories as $key => $value) { 
						$term_link = get_term_link($value->term_id , 'casestudies-cat' );
					?>
					<li><a href="<?php echo $term_link ?>"><?php echo $value->name; ?></a></li>
					
					<?php } ?>
				</ul>
			</div>
		</div>
		<section class="page_content_wrapper">
			<?php
				 $terms = wp_get_post_terms( $post->ID,'casestudies-cat'); 
				$industry_name = $terms[0]->name; ?>
			<div class="triangle_box">
				<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
				<div class="tech_box">
					<span>Why tech?</span>
				</div>
				
				<div class="hexagon_title_box">
					<div class="industry_hexagon" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/home/feature_1.jpg');">
						<div class="industry_color_overlay" style="background-color: rgba(0, 137, 207, 0.8);"></div>
						<div class="industry_text"><?php echo $industry_name; ?></div>
					</div>
				</div>
				
			</div>
			<div class="page_content">
				<div class="container">
					<div class="row">
					<?php 

					while ( have_posts() ) : the_post(); ?>

						<div class="col-xs-12 col-sm-12 col-md-12">
							<h1 class="section_head margin_bottom_20"><?php the_title(); ?> Case Study</h1>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-8">
							<h2 class="section_sub_head margin_bottom_20"><?php the_field('sub_heading'); ?></h2>
						</div>
						<?php if(has_post_thumbnail()){
							$class = 'col-md-8' ;
						}else{
							$class = 'col-md-12' ;
							} ?>
						<div class="col-xs-12 col-sm-12 <?php echo $class; ?>">
							<div class="page_vc_content">
								<?php the_content(); ?> 
							</div>
						</div>
						<?php if(has_post_thumbnail()) : ?>
						<div class="col-xs-12 col-sm-12 col-md-4">
								<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" class="margin_bottom_30" width="100%"> 
								<?php if( have_rows('website_awards_image_and_text') ): ?>
								<h2 class="sidebar_wrap_head sidebar_wrap_head-border">Award Winning</h2>
								<?php $i = 1;
								 while ( have_rows('website_awards_image_and_text') ) : the_row();
								?>
								<div class="cs-award-image custom<?php echo $i;?>">
									<!--div class="award_img_case_study" style="background-image: url('<?php //the_sub_field("website_awards_image"); ?>'); background-size: contain;">
									</div-->
								<img src="<?php the_sub_field('website_awards_image'); ?>" alt="" width="100%">
								<br/><br/>
								<strong><?php the_sub_field('winning_awards_category'); ?></strong>
								<br/><br/>
							</div>
								<?php $i++; endwhile; endif; ?>
						</div>
						<?php endif ; ?>	
					<?php endwhile;	?>
					</div>
				</div>
			</div>
		</section>	
	</div>
</main>

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
