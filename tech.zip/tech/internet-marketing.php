<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<main>
	<?php if( get_field('banner_image',10) ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image',10); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h1>Marketing</h1>
				</div>
			</div>
		</div>	
	</section>
		

	<div class="page_outer">
		<div class="submenu_wrap submenu_plus">
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
			<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
		</div>
		<?php 
			$categories = get_terms(
						array('marketing-category'),
						array(
						        'hide_empty'    => false,
						        'orderby'       => 'title',
						        'order'         => 'ASC'
						    )
						);
				//print_r($categories);

		?>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<ul>
					<?php foreach ($categories as $key => $value) { 
						$term_link = get_term_link($value->term_id , 'marketing-category' );
					?>
					<li><a href="<?php echo $term_link ?>"><?php echo $value->name; ?></a></li>
					
					<?php } ?>
				</ul>
			</div>
		</div>
		<section class="page_content_wrapper">
			<?php
				 $terms = wp_get_post_terms( $post->ID,'marketing-category'); 
				$industry_name = $terms[0]->name; ?>
			<div class="triangle_box">
	
				<div class="tech_box">
					<span>Why tech?</span>
				</div>
				<div class="hexagon_title_box">
						<div class="industry_color_overlay" style="background-color: rgba(0, 137, 207, 0.8);"></div>
						<div class="industry_text"><?php echo $industry_name; ?></div>
					</div>
				</div>
				
			</div>
			<div class="page_content">
				<div class="container">
					<div class="row">
					<?php 

					while ( have_posts() ) : the_post(); ?>

						<div class="col-xs-12 col-sm-12 col-md-12">
							<h2 class="section_head margin_bottom_20"><?php the_title(); ?></h2>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-8">
							<h2 class="section_sub_head margin_bottom_20"><?php the_field('sub_heading'); ?></h2>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-8">
							<div class="page_vc_content">
								<?php the_content(); ?> 
							</div>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-4">
						<?php if(has_post_thumbnail()) : ?>							
							<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="" width="100%">
						<?php else: ?>
							<img src="<?php echo get_stylesheet_directory_uri()?>/images/home/slide1_bg.jpg" alt="" width="100%">
						<?php endif ; ?>
						</div>	
					<?php endwhile;	?>
					</div>
				</div>
			</div>
		</section>	
	</div>
</main>

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
