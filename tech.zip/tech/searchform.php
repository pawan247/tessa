<?php
/**
 * Template for displaying search forms in Twenty Sixteen
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

<form role="search" method="get" class="search-form search_form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<!-- <span class="screen-reader-text"><?php //echo _x( 'Search for:', 'label', 'twentysixteen' ); ?></span> -->
	<input type="search" class="search-field seacrh_field" placeholder="Search.." value="<?php echo get_search_query(); ?>" name="s" />
	<button type="submit" class="search-submit search_submit"><i class="fa fa-search"></i><!-- <span class="screen-reader-text"><?php //echo _x( 'Search', 'submit button', 'twentysixteen' ); ?></span> --></button>
</form>
