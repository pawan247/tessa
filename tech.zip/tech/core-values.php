	<?php
/**
Template Name: core values template
 */

get_header(); ?>

<main>
	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12">
						<h2><?php the_title(); ?></h2>
					</div>
				</div>
			</div>	
	</section>
<div class="page_outer">
	<div class="submenu_wrap submenu_minus">
		<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_plus.png" alt="" class="plus_icon submenu_icon" />
		<img src="<?php echo get_stylesheet_directory_uri()?>/images/case_studies/menu_minus.png" alt="" class="minus_icon submenu_icon" />
		<div class="menu-heading">Menu</div>
	</div>
	<?php
	global $post;
	
    //GET CHILD PAGES IF THERE ARE ANY
    $children = get_pages('child_of='.$post->ID);
 
    //GET PARENT PAGE IF THERE IS ONE
    $parent = $post->post_parent;
    //echo $parent ; 
 
    //DO WE HAVE SIBLINGS?
    $siblings =  get_pages('child_of='.$parent);
    //print_r($siblings);
 
    if( count($children) != 0) {
       $args = array(
         'depth' => 1,
         'title_li' => '',
         'child_of' => $post->ID
       );
 
    } elseif($parent != 0) {
        $args = array(
             'depth' => 1,
             'title_li' => '',
             'exclude' => $post->ID,
             'child_of' => $parent
           );
    }
    $parent_id = get_post_ancestors( $post->ID );
    //Show pages if this page has more than one sibling 
    // and if it has children 
    if(count($siblings) > 1 && !is_null($args))   
    { ?>
		<div class="submenu_box">
			<div class="submenu_box_neutral">
				<ul class="pages-list">
					<li><a href="<?php the_permalink($parent_id[0]); ?>"><?php echo get_the_title($parent_id[0]); ?></a></li>
	         		<?php wp_list_pages($args);  ?>
	         </ul>
			</div>
		</div>
	<?php } ?>			
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="triangle_box_position"></div><!-- to get offset posiion of triangle box -->
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">
				<?php 

				while ( have_posts() ) : the_post(); ?>

					<div class="col-xs-12 col-sm-12 col-md-12">
						<h1 class="section_head margin_bottom_20"><?php the_title(); ?></h1>
						<h2 class="section_sub_head margin_bottom_20"><?php the_field('sub_heading'); ?></h2>
					</div>
					<?php if(has_post_thumbnail()) : ?>
					<div class="col-xs-12 col-sm-12 col-md-8">
					<?php else : ?>
					<div class="col-xs-8 col-sm-8 col-md-8">
					<?php endif ; ?>
						<div class="page_vc_content">
							<?php the_content(); ?> 
						</div>
						<?php dynamic_sidebar('techo-marketing-sidebar'); ?>
					</div>
				
					<div class="col-xs-12 col-sm-12 col-md-4">
								<div class="margin_bottom_30">
								<div class="challenge-box">
									<div class="row">
										<p><img id="loading" class="w3-spin" src="<?php echo site_url(); ?>/wp-content/themes/techchild/images/icon-thumbsup-simple.png" /></p>
										<h1>Challenge Us?</h1>
										<div class="call-action-button"><a>Call 800.586.1553</a></div>
									</div>
								</div>
							</div>
						<!-- <div class="margin_bottom_30">
							<h2 class="sidebar_wrap_head sidebar_wrap_head-border">Award Winning Website Design</h2>
						</div> -->
						<div class="margin_bottom_30">
							<h2 class="sidebar_wrap_head sidebar_wrap_head-border">Testimonials</h2>
							<?php echo do_shortcode('[testimonial_slider]'); ?>
						</div>
					</div>
				<?php endwhile;	?>
				</div>
			</div>
		</div>
	</section>	
</div>	
</main>


<?php// get_sidebar(); ?>
<?php get_footer(); ?>



