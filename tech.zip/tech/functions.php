<?php
/* Parent css */ 
/*add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );
function my_theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
*/
/* Enquing Scripts */

/* Admin Juqery for Phone Number */
/*function wpdocs_scripts_method() {
    wp_enqueue_script( 'custom-script', get_stylesheet_directory_uri() . '/js/phone_validate.js', array( 'jquery' ) );
    
}
add_action( 'admin_enqueue_scripts', 'wpdocs_scripts_method' );*/

/* Logo Section */
function tessa_theme_customizer( $wp_customize ) {
$wp_customize->add_section( 'tessa_logo_section' , array(
    'title'       => __( 'Logo', 'tessa' ),
    'priority'    => 30,
    'description' => 'Upload a logo to replace the default site name and description in the header',
) );
$wp_customize->add_setting( 'tessa_logo' );

$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'tessa_logo', array(
    'label'    => __( 'Logo', 'tessa' ),
    'section'  => 'tessa_logo_section',
    'settings' => 'tessa_logo',
) ) );

}
add_action('customize_register', 'tessa_theme_customizer');

function wpdocs_scripts_method() {
   // wp_enqueue_script( 'slick-script', get_stylesheet_directory_uri() . '/vendor/slick/slick.min.js', array( 'jquery' ) );
    wp_enqueue_script( 'custom-script', get_stylesheet_directory_uri() . '/js/custom.js', array(), '1.0.0', true );
    
}
add_action( 'wp_enqueue_scripts', 'wpdocs_scripts_method' );


/* Footer Menu */
function register_my_menus() {
register_nav_menus(
array(
'footer-main-menu' => __( 'Footer Menu','twentysixteen' )
));
}
add_action( 'init', 'register_my_menus' );

/* Theme Options */
function theme_settings_page()
{
    ?>
        <div class="wrap">
        <h1>Theme Options</h1>
        <form action="options.php" method="post" enctype="multipart/form-data">
            <?php
                settings_fields("section");
                do_settings_sections("theme-options");   
                submit_button(); 
            ?> 
        </form>
        
        </div>

    <?php
}
function display_all($value='')
{   ?>
			<table>
            <tr>
                <td><label>Footer Contact Details :</label></td>
                <td><textarea name="my_address" id="my_address"  rows="2" cols="30" ><?php echo get_option('my_address'); ?></textarea></td>
            </tr>
             <tr>
                <td><label>Award Winnig Image Link 1:</label></td>
                <td><input type="text" name="award_winnig_image_1" id="award_winnig_image"  size="30" value="<?php echo get_option('award_winnig_image_1'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Award Winnig Url 1:</label></td>
                <td><input type="text" name="award_winnig_url_1" id="all_award_winnig_image_link"  size="30" value="<?php echo get_option('award_winnig_url_1'); ?>" /></td>
            </tr>

              <tr>
                <td><label>Award Winnig Image Link 2:</label></td>
                <td><input type="text" name="award_winnig_image_2" id="award_winnig_image_2"  size="30" value="<?php echo get_option('award_winnig_image_2'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Award Winnig Url 2:</label></td>
                <td><input type="text" name="award_winnig_url_2" id="all_award_winnig_image_link"  size="30" value="<?php echo get_option('award_winnig_url_2'); ?>" /></td>
            </tr>
              <tr>
                <td><label>Award Winnig Image Link 3:</label></td>
                <td><input type="text" name="award_winnig_image_3" id="all_award_winnig_image_link"  size="30" value="<?php echo get_option('award_winnig_image_3'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Award Winnig Url 3:</label></td>
                <td><input type="text" name="award_winnig_url_3" id="all_award_winnig_image_link"  size="30" value="<?php echo get_option('award_winnig_url_3'); ?>" /></td>
           </tr>
           <!--     
              <tr>
                <td><label>Award Winnig Image Link 4:</label></td>
                <td><input type="text" name="award_winnig_image_4" id="award_winnig_image"  size="30" value="<?php //echo get_option('award_winnig_image_4'); ?>" /></td>
            </tr> -->
          
        <!--       <tr>
                <td><label>Award Winnig Image Link 5:</label></td>
                <td><input type="text" name="award_winnig_image_5" id="award_winnig_image"  size="30" value="<?php //echo get_option('award_winnig_image_5'); ?>" /></td>
            </tr>
              <tr>
                <td><label>Award Winnig Image Link 6:</label></td>
                <td><input type="text" name="award_winnig_image_6" id="award_winnig_image"  size="30" value="<?php //echo get_option('award_winnig_image_6'); ?>" /></td>
            </tr>
              <tr>
                <td><label>Award Winnig Image Link 7:</label></td>
                <td><input type="text" name="award_winnig_image_7" id="award_winnig_image"  size="30" value="<?php //echo get_option('award_winnig_image_7'); ?>" /></td>
            </tr> -->
          <!--     <tr>
                <td><label>All Award Winnig Image Link:</label></td>
                <td><input type="text" name="all_award_winnig_image_link" id="all_award_winnig_image_link"  size="30" value="<?php //echo get_option('all_award_winnig_image_link'); ?>" /></td>
            </tr> -->
            <tr>
                <td><label>Phone No :</label></td>
                <td><input type="text" name="my_phone" id="my_phone"  size="30" value="<?php echo get_option('my_phone'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Facebook Link :</label></td>
                <td><input type="text" name="fb_url" id="fb_url"  size="30" value="<?php echo get_option('fb_url'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Twitter Link :</label></td>
                <td><input type="text" name="twitter_url" id="twitter_url"  size="30" value="<?php echo get_option('twitter_url'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Linkedin Link :</label></td>
                <td><input type="text" name="linkedin_url" id="linkedin_url"  size="30" value="<?php echo get_option('linkedin_url'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Youtube Link :</label></td>
                <td><input type="text" name="youtube_url" id="youtube_url"  size="30" value="<?php echo get_option('youtube_url'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Google Plus Link :</label></td>
                <td><input type="text" name="googleplus_url" id="googleplus_url"  size="30" value="<?php echo get_option('googleplus_url'); ?>" /></td>
            </tr>
            <tr>
                <td><label>Instagram Link :</label></td>
                <td><input type="text" name="instagram_url" id="instagram_url"  size="30" value="<?php echo get_option('instagram_url'); ?>" /></td>
            </tr>
            </table>
            
    <?php
}
function display_theme_fields()
{
    add_settings_section("section", "Contact Information", null, "theme-options");
    add_settings_field("my_phone", "","display_all", "theme-options", "section");
    add_settings_field("my_address", "","theme-options", "section");
    add_settings_field("fb_url", "","theme-options", "section");
    add_settings_field("twitter_url", "","theme-options", "section");
    add_settings_field("googleplus_url", "","theme-options", "section");
    add_settings_field("linkedin_url", "","theme-options", "section");
    add_settings_field("youtube_url", "","theme-options", "section");
    add_settings_field("instagram_url", "","theme-options", "section");
    add_settings_field("award_winnig_text", "","theme-options", "section");
    add_settings_field("award_winnig_image_1", "","theme-options", "section");
    add_settings_field("award_winnig_image_2", "","theme-options", "section");
    add_settings_field("award_winnig_image_3", "","theme-options", "section");
    add_settings_field("award_winnig_image_4", "","theme-options", "section");
    add_settings_field("award_winnig_image_5", "","theme-options", "section");
    add_settings_field("award_winnig_image_6", "","theme-options", "section");
    add_settings_field("award_winnig_image_7", "","theme-options", "section");
    add_settings_field("award_winnig_url_1", "","theme-options", "section");
    add_settings_field("award_winnig_url_2", "","theme-options", "section");
    add_settings_field("award_winnig_url_3", "","theme-options", "section");

    register_setting("section", "my_phone");
    register_setting("section", "my_address");
    register_setting("section", "fb_url");
    register_setting("section", "twitter_url");
    register_setting("section", "googleplus_url");
    register_setting("section", "linkedin_url");
    register_setting("section", "youtube_url");
    register_setting("section", "instagram_url");
    register_setting("section", "award_winnig_image_1");
    register_setting("section", "award_winnig_image_2");
    register_setting("section", "award_winnig_image_3");
    register_setting("section", "award_winnig_image_4");
    register_setting("section", "award_winnig_image_5");
    register_setting("section", "award_winnig_image_6");
    register_setting("section", "award_winnig_image_7");
    register_setting("section", "award_winnig_url_1");
    register_setting("section", "award_winnig_url_2");
    register_setting("section", "award_winnig_url_3");

}
add_action("admin_init", "display_theme_fields");

function my_theme_menu() 
{
    add_theme_page('My Theme options', 'Theme options', 'edit_theme_options', 'my-theme-settings', 'theme_settings_page');
}
add_action('admin_menu', 'my_theme_menu');
/*Media Images Uploads*/

add_filter( 'wp_image_editors', 'change_graphic_lib' );

function change_graphic_lib($array) {
return array( 'WP_Image_Editor_GD', 'WP_Image_Editor_Imagick' );
}

/*  Including External shortcode file and post type file */
include( get_stylesheet_directory() . '/includes/shortcode.php');
include( get_stylesheet_directory() . '/includes/custom_post_type.php');


// gform


// http://www.jordancrown.com/multi-column-gravity-forms/
function gform_column_splits( $content, $field, $value, $lead_id, $form_id ) {
    if( !IS_ADMIN ) { // only perform on the front end

        // target section breaks
        if( $field['type'] == 'section' ) {
            $form = RGFormsModel::get_form_meta( $form_id, true );

            // check for the presence of multi-column form classes
            $form_class = explode( ' ', $form['cssClass'] );
            $form_class_matches = array_intersect( $form_class, array( 'two-column', 'three-column' ) );
            // check for the presence of section break column classes
            $field_class = explode( ' ', $field['cssClass'] );
            $field_class_matches = array_intersect( $field_class, array('gform_column') );
            // if field is a column break in a multi-column form, perform the list split
            if( !empty( $form_class_matches ) && !empty( $field_class_matches ) ) { // make sure to target only multi-column forms
                // retrieve the form's field list classes for consistency
                $form = RGFormsModel::add_default_properties( $form );
                $description_class = rgar( $form, 'descriptionPlacement' ) == 'above' ? 'description_above' : 'description_below';
                // close current field's li and ul and begin a new list with the same form field list classes
                return '</li></ul><ul class="gform_fields '.$form['labelPlacement'].' '.$description_class.' '.$field['cssClass'].'">';

            }
        }
    }

    return $content;
}
add_filter( 'gform_field_content', 'gform_column_splits', 10, 5 );

// Enqueue Scripts on Contact Page
add_action( 'wp_enqueue_scripts', 'sk_enqueue_scripts' );
function sk_enqueue_scripts() {
    if ( ! is_page( 'home' ) ) {
        return;
    }
}

foreach ( array( 'pre_term_description' ) as $filter ) {
    remove_filter( $filter, 'wp_filter_kses' );
}
 
foreach ( array( 'term_description' ) as $filter ) {
    remove_filter( $filter, 'wp_kses_data' );
}

function arphabet_widgets_init() {

     register_sidebar( array(
        'name'          => __( 'Blogs Sidebar', 'twentysixteen' ),
        'id'            => 'blog-sidebar',
        'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );


     register_sidebar( array(
        'name'          => __( 'Technology & Marketing Awards', 'twentysixteen' ),
        'id'            => 'techo-marketing-sidebar',
        'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );

}

add_action( 'widgets_init', 'arphabet_widgets_init' );

add_image_size( 'my_slider', 640, 480, true ); // 640 - slider width, 480 - slider height

add_filter('next_posts_link_attributes', 'posts_link_attributes');
//add_filter('previous_posts_link_attributes', 'posts_link_attributes');

function posts_link_attributes() {
    return 'class="styled-button"';
}



function override_mce_options($initArray) 
{
  $opts = '*[*]';
  $initArray['valid_elements'] = $opts;
  $initArray['extended_valid_elements'] = $opts;
  return $initArray;
 }
 add_filter('tiny_mce_before_init', 'override_mce_options'); 

 // add the 'novalidate' setting to <form> tag
// stackoverflow.com/questions/3090369/
function my_novalidate($form_tag, $form) {

  // collect field types
  $types = array();
  foreach ( $form['fields'] as $field ) {
    $types[] = $field['type'];
  }

  // bail if form doesn't have a website field
  if ( ! in_array('website', $types) )
    return $form_tag; 

  // add the 'novalidate' setting to the website <form> element
  $pattern = "#method=\'post\'#i";
  $replacement = "method='post' novalidate";
  $form_tag = preg_replace($pattern, $replacement, $form_tag);

  return $form_tag;
}
//add_filter('gform_form_tag','my_novalidate',10,2);

// add "http://" to website if protocol omitted
function my_protocol($form) {

  // loop through fields, taking action if website
  foreach ( $form['fields'] as $field ) {

  // skip if not a website field
  if ( 'website' != $field['type'] )
      continue;

  // retrieve website field value
  $value = RGFormsModel::get_field_value($field);

  // if there is no protocol, add "http://"
  // Recognizes ftp://, ftps://, http://, https://
  // stackoverflow.com/questions/2762061/
  if ( ! empty($value) && ! preg_match("%^((https?://)|(www\.))([a-z0-9-].?)+(:[0-9]+)?(/.*)?$%i", $value) ) {
    $value = "http://" . $value;

    // update value in the $_POST array
    $id = (string) $field['id'];
    $_POST['input_' . $id] = $value;
  }
  }

  return $form;
}
//add_filter('gform_pre_validation','my_protocol');
