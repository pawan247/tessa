<?php 
/*
Template Name: Blog Template
*/
?>
<?php get_header(); ?>

<main>

	<?php if( get_field('banner_image') ): ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php the_field('banner_image'); ?>');"></div>
	<?php else: ?>
		<section class="page_banner">
			<div class="header_img" style="background-image: url('<?php echo get_stylesheet_directory_uri()?>/images/case_studies/case_banner.jpg');"></div>
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<h2>Blog</h2>
				</div>
			</div>
		</div>	
	</section>
		
	<section class="page_content_wrapper">
		<div class="triangle_box">
			<div class="tech_box">
				<span>Why tech?</span>
			</div>
		</div>
		<div class="page_content">
			<div class="container">
				<div class="row">

					<div class="col-xs-12 col-sm-8 col-md-9" id="blog_list">
						<div class="row">
							<div class="col-xs-12 col-sm-12 col-md-12 cat_slider_outer">
								<div class="cat_previous">
									<i class="fa fa-angle-left"></i>
								</div>
								<div class="cat_next">
									<i class="fa fa-angle-right"></i>
								</div>

								<div class="cat_slider">
									<?php $args = array('hide_empty' => 0 , 'exclude'=>'1');
									$post_cat = get_categories($args); 
									//print_r($post_cat); ?>
									<?php foreach($post_cat as $cat): ?>
										<div class="cat_slide">
											<h4>
												<a href="<?php echo get_category_link($cat->term_id) ?>"><?php echo $cat->name; ?></a>
											</h4>
										</div>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
						<div class="row blogs_content">
							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="blog_list_wrapper">

									<?php 
										$paged = (get_query_var('paged')) ? get_query_var('paged') : 1 ;
										$args = array(
										'post_type'=> 'post',
										'post_status' => 'publish',
										'paged'		=> $paged,
										'posts_per_page' => 10 // this will retrive all the post that is published 
										);
										$result = new WP_Query( $args );
										$count = $result->post_count;
									if ( $result-> have_posts() ) : ?>
									<?php while ( $result->have_posts() ) : $result->the_post(); ?>
										<div class="blog_list_outer">
											<h2 class="blog_head"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
											<div class="blog_text_wrap">
												<?php if(has_post_thumbnail()) : ?>	
													<div class="blog_feature_img" style="background-image: url('<?php echo get_the_post_thumbnail_url(); ?>');"></div>
												<?php endif ; ?>
												<div class="blog_text">
													<p class="margin_bottom_0 blog_date_time"><?php the_time('F jS, Y') ?></p>
													<?php if(get_the_content()) : ?>
														<p><?php $desc = get_the_content();
												 		echo substr(strip_tags($desc),0,200).'...';
														 ?><a href="<?php the_permalink(); ?>">&nbsp; Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
													<?php endif ; ?>
													<div class="blog_meta_wrap">
														<ul class="blog_social_list">
															<li><a 
															href="javascript:void(0)" onclick="javascript:genericSocialShare('http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>')"><img width="25" src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/facebook_black.png"></a></li>

															<li><a 
															href="javascript:void(0)" onclick="javascript:genericSocialShare('http://twitter.com/share?text=<?php the_title(); ?>&url=<?php the_permalink();?>')"><img width="25" src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/twitter_black.png"></a></li>
															<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('http://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title(); ?>&amp;url=<?php the_permalink(); ?>')"><img width="25" src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/linked_in_black.png"></a></li>
															<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('https://plus.google.com/share?url=<?php the_permalink(); ?>')"><img width="25" src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/google_plus_black.png"></a></li>
															<li><a href="javascript:void(0)" onclick="javascript:genericSocialShare('http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>')"><img width="25" src="<?php echo get_stylesheet_directory_uri()?>/images/social_icon/pinterest_black.png"></a></li>
														</ul>
														<?php $posttags = get_the_tags();
														if ($posttags) { ?>
															<ul class="blog_cloud_list">
																<?php foreach($posttags as $tag) { ?>
																<li><a href="<?php echo get_tag_link($tag->term_id); ?>"><?php echo $tag->name; ?></a></li>
																<?php } ?>
															</ul>
														<?php } ?>	
													</div>
												</div>
											</div>
										</div>  
									<?php endwhile; ?>
									<?php endif; wp_reset_postdata(); ?>
									  <nav class="prev-next-posts">
									      <?php echo get_next_posts_link( 'Older Entries',$result->max_num_pages); // display older posts link ?>
									      <?php echo get_previous_posts_link( 'Newer Entries' ); // display newer posts link ?>
									  </nav> 
									<?php //} ?>
								</div>
							<?php if($count==5 || $count>5) :  ?>
								<div class="see_list_wrap">
									<a id="see_list" href="#blog_list" title="To Top"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
								</div>
							<?php endif ; ?>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-3">
						 <?php get_sidebar('blogs'); ?>
					</div>	
				</div>
			</div>
			
		</div>
		
	</section>	

</main>

<?php get_footer(); ?>